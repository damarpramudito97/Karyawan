@php
    $mapId = 'location-map-' . uniqid();
@endphp

<div
    id="{{ $mapId }}"
    wire:ignore
    style="height: 300px; border-radius: 0.5rem; overflow: hidden;"
    x-data="{}"
    x-init="
        const map = L.map($el).setView([{{ $lat }}, {{ $lng }}], 16);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        const marker = L.marker([{{ $lat }}, {{ $lng }}]).addTo(map);
        const circle = L.circle([{{ $lat }}, {{ $lng }}], {
            radius: {{ $radius }},
            color: '#1D9E75',
            fillColor: '#1D9E75',
            fillOpacity: 0.15,
        }).addTo(map);
    "
></div>

@once
    @push('styles')
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css" />
    @endpush
    @push('scripts')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
    @endpush
@endonce

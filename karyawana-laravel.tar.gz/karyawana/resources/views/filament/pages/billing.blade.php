<x-filament-panels::page>
    @php
        $company = $this->getCompany();
    @endphp

    <div class="rounded-lg border p-4" style="border-color: var(--gray-200);">
        <p class="text-sm text-gray-500">Paket Saat Ini</p>
        <p class="text-lg font-medium">{{ $company->subscriptionPlan?->name ?? 'Belum berlangganan' }}</p>
        <p class="text-sm text-gray-500">
            Status:
            <span class="font-medium">{{ ucfirst($company->subscription_status) }}</span>
            @if ($company->subscription_ends_at)
                &middot; Berlaku sampai {{ $company->subscription_ends_at->format('d M Y') }}
            @endif
        </p>
    </div>

    <div class="mt-6">
        <h2 class="text-base font-medium mb-3">Pilih Paket</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            @foreach ($this->getPlans() as $plan)
                <div class="rounded-lg border p-4" style="border-color: var(--gray-200);">
                    <p class="font-medium">{{ $plan->name }}</p>
                    <p class="text-sm text-gray-500 mb-2">{{ $plan->description }}</p>
                    <p class="text-xl font-medium">
                        Rp {{ number_format($plan->price, 0, ',', '.') }}
                        <span class="text-sm text-gray-500">/ {{ $plan->billing_cycle === 'yearly' ? 'tahun' : 'bulan' }}</span>
                    </p>
                    <ul class="text-sm text-gray-500 mt-2 mb-4 list-disc list-inside">
                        @foreach ($plan->features ?? [] as $feature)
                            <li>{{ $feature }}</li>
                        @endforeach
                    </ul>
                    <x-filament::button
                        wire:click="$dispatch('checkout', { planId: {{ $plan->id }} })"
                        x-on:click="
                            fetch('/billing/checkout/{{ $plan->id }}', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                },
                            })
                            .then(r => r.json())
                            .then(data => { window.location.href = data.redirect_url; });
                        "
                    >
                        Pilih Paket
                    </x-filament::button>
                </div>
            @endforeach
        </div>
    </div>

    <div class="mt-6">
        <h2 class="text-base font-medium mb-3">Riwayat Pembayaran</h2>
        <table class="w-full text-sm">
            <thead>
                <tr class="text-left text-gray-500">
                    <th class="py-2">No. Invoice</th>
                    <th class="py-2">Tanggal</th>
                    <th class="py-2">Jumlah</th>
                    <th class="py-2">Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($this->getPaymentHistory() as $payment)
                    <tr class="border-t" style="border-color: var(--gray-100);">
                        <td class="py-2">{{ $payment->invoice_number }}</td>
                        <td class="py-2">{{ $payment->created_at->format('d M Y H:i') }}</td>
                        <td class="py-2">Rp {{ number_format($payment->amount, 0, ',', '.') }}</td>
                        <td class="py-2">{{ ucfirst($payment->status) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</x-filament-panels::page>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: sans-serif; font-size: 11px; color: #2C2C2A; }
        h1 { font-size: 16px; margin-bottom: 0; }
        .subtitle { color: #5F5E5A; margin-top: 2px; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #D3D1C7; padding: 4px 6px; text-align: left; }
        th { background-color: #F1EFE8; }
        .text-right { text-align: right; }
        .badge-danger { color: #791F1F; font-weight: bold; }
    </style>
</head>
<body>
    <h1>Rekap Kehadiran &mdash; {{ $company->name ?? 'Karyawana' }}</h1>
    <p class="subtitle">Dicetak pada {{ $generatedAt->format('d M Y H:i') }}</p>

    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Karyawan</th>
                <th>Shift</th>
                <th>Lokasi</th>
                <th>Check-in</th>
                <th>Check-out</th>
                <th class="text-right">Telat (mnt)</th>
                <th class="text-right">Pulang Awal (mnt)</th>
                <th class="text-right">Lembur (mnt)</th>
                <th>Status</th>
                <th>Fake GPS</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($attendances as $attendance)
                <tr>
                    <td>{{ $attendance->date->format('d-m-Y') }}</td>
                    <td>{{ $attendance->employee->name }}</td>
                    <td>{{ $attendance->shift?->name }}</td>
                    <td>{{ $attendance->location?->name }}</td>
                    <td>{{ $attendance->check_in_at?->format('H:i:s') }}</td>
                    <td>{{ $attendance->check_out_at?->format('H:i:s') }}</td>
                    <td class="text-right">{{ $attendance->late_minutes }}</td>
                    <td class="text-right">{{ $attendance->early_leave_minutes }}</td>
                    <td class="text-right">{{ $attendance->overtime_minutes }}</td>
                    <td>{{ ucfirst($attendance->status) }}</td>
                    <td class="{{ $attendance->check_in_is_mock_location ? 'badge-danger' : '' }}">
                        {{ $attendance->check_in_is_mock_location ? 'Ya' : '-' }}
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>

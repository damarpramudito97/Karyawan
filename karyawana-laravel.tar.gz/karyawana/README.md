# Karyawana — Fase 1: Database & Model Inti (Laravel)

Berisi pondasi multi-tenant untuk aplikasi Karyawana.

## Cara Menggunakan

1. Buat project Laravel baru (jika belum ada):
   ```bash
   composer create-project laravel/laravel karyawana
   cd karyawana
   composer require laravel/sanctum
   ```

2. Copy folder berikut ke project Laravel kamu (replace/merge):
   - `app/Models/*` → `app/Models/`
   - `app/Traits/*` → `app/Traits/`
   - `database/migrations/*` → `database/migrations/`
   - `database/seeders/*` → `database/seeders/`

3. Set koneksi database di `.env`, lalu jalankan migrasi:
   ```bash
   php artisan migrate
   php artisan db:seed --class=SubscriptionPlanSeeder
   ```

4. Buat company & user pertama (contoh via tinker):
   ```bash
   php artisan tinker
   ```
   ```php
   $company = \App\Models\Company::create([
       'name' => 'PT Contoh Sukses',
       'slug' => 'pt-contoh-sukses',
       'subscription_plan_id' => 1,
       'subscription_status' => 'trial',
       'trial_ends_at' => now()->addDays(14),
   ]);

   \App\Models\User::create([
       'company_id' => $company->id,
       'name' => 'Admin Perusahaan',
       'email' => 'admin@contoh.com',
       'password' => bcrypt('password'),
       'role' => 'admin',
   ]);

   \App\Models\User::create([
       'name' => 'Super Admin',
       'email' => 'superadmin@karyawana.com',
       'password' => bcrypt('password'),
       'role' => 'super_admin',
   ]);
   ```

## Cara Kerja Multi-Tenant

- Model yang menggunakan trait `BelongsToCompany` (Department, Division, Location,
  Employee, Shift, WorkSchedule, Attendance, LeaveRequest, Setting) **otomatis**
  difilter berdasarkan `company_id` user yang sedang login.
- User dengan `role = super_admin` **tidak** terkena filter ini — bisa melihat
  semua data lintas tenant.
- Untuk query lintas tenant secara manual (misal di job/queue tanpa auth),
  gunakan scope: `Model::allCompanies()->...`

## Struktur File

```
app/
  Models/
    Company.php
    SubscriptionPlan.php
    Subscription.php
    Payment.php
    User.php
    Department.php
    Division.php
    Location.php
    Employee.php
    Shift.php
    WorkSchedule.php
    Attendance.php
    LeaveRequest.php
    Setting.php
  Traits/
    BelongsToCompany.php
database/
  migrations/
    2024_01_01_000001_create_subscription_plans_table.php
    ... (15 migration files, urut sesuai dependency)
  seeders/
    SubscriptionPlanSeeder.php
SPEC.md   <- dokumen spesifikasi lengkap & roadmap
```

## Langkah Berikutnya (Fase 2)

- Setup Sanctum untuk autentikasi API (Flutter)
- Buat controller & route API:
  - `POST /api/login`
  - `POST /api/attendance/check-in`
  - `POST /api/attendance/check-out`
  - `GET /api/schedule`
  - `POST /api/leave-requests`
  - `GET /api/leave-requests`
- Validasi geofence (gunakan `Location::isWithinRadius()`) & flag mock location
  pada saat check-in/check-out

Lihat `SPEC.md` untuk roadmap fase 3–7 (Web Admin Panel, Laporan, Subscription
& Payment, Super Admin Panel, Mobile App Flutter).

---

# Fase 2: API Mobile (Flutter) — Sudah Diimplementasikan

## Setup

1. Install Sanctum:
   ```bash
   composer require laravel/sanctum
   php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
   php artisan migrate
   ```

2. Daftarkan middleware role di `bootstrap/app.php` (Laravel 11):
   ```php
   ->withMiddleware(function (Middleware $middleware) {
       $middleware->alias([
           'role' => \App\Http\Middleware\EnsureUserHasRole::class,
       ]);
   })
   ```

3. Pastikan storage link sudah dibuat (untuk menyimpan & menampilkan foto selfie):
   ```bash
   php artisan storage:link
   ```

4. Jalankan seeder default settings (sekali per company, atau jalankan
   `DefaultSettingsSeeder` untuk semua company yang sudah ada):
   ```bash
   php artisan db:seed --class=DefaultSettingsSeeder
   ```

## Daftar Endpoint API

| Method | Endpoint | Keterangan |
|---|---|---|
| POST | `/api/login` | Login (mobile & web), mengembalikan Sanctum token |
| GET | `/api/me` | Profil user yang login |
| POST | `/api/logout` | Logout (revoke token) |
| GET | `/api/attendance/today` | Status presensi hari ini |
| GET | `/api/attendance/history?month=2026-06` | Riwayat presensi bulanan |
| POST | `/api/attendance/check-in` | Check-in (GPS + selfie, multipart/form-data) |
| POST | `/api/attendance/check-out` | Check-out (GPS + selfie, multipart/form-data) |
| GET | `/api/schedule/today` | Jadwal kerja hari ini |
| GET | `/api/schedule/week?start=2026-06-09` | Jadwal kerja 1 minggu |
| GET | `/api/leave-requests` | Daftar pengajuan milik karyawan login |
| POST | `/api/leave-requests` | Ajukan cuti/izin/sakit/lembur/wfh/wfa |
| GET | `/api/leave-requests/{id}` | Detail pengajuan |
| POST | `/api/leave-requests/{id}/cancel` | Batalkan pengajuan (status pending) |
| GET | `/api/admin/leave-requests?status=pending` | (admin) daftar semua pengajuan |
| POST | `/api/admin/leave-requests/{id}/approve` | (admin) setujui pengajuan |
| POST | `/api/admin/leave-requests/{id}/reject` | (admin) tolak pengajuan |

## Contoh Request: Check-in

```bash
curl -X POST https://api.karyawana.test/api/attendance/check-in \
  -H "Authorization: Bearer {token}" \
  -H "Accept: application/json" \
  -F "latitude=-7.797068" \
  -F "longitude=110.370529" \
  -F "accuracy=8.5" \
  -F "is_mock_location=false" \
  -F "selfie=@/path/to/selfie.jpg" \
  -F "notes="
```

Response:
```json
{
  "message": "Check-in berhasil.",
  "data": {
    "id": 101,
    "date": "2026-06-12",
    "status": "present",
    "check_in": {
      "time": "2026-06-12 07:58:11",
      "photo_url": "https://api.karyawana.test/storage/attendance-selfies/1/12/check_in_20260612_075811_12.jpg",
      "latitude": -7.797068,
      "longitude": 110.370529,
      "accuracy": 8.5,
      "distance_meters": 32.4,
      "within_radius": true,
      "is_mock_location": false
    },
    "late_minutes": 0,
    "early_leave_minutes": 0,
    "overtime_minutes": 0
  }
}
```

## Validasi Otomatis yang Diterapkan

Logika ada di `app/Services/AttendanceService.php`, dikontrol via tabel `settings`
(per company), dengan key:

- `require_selfie` (default `1`) — wajib upload foto selfie
- `reject_mock_location` (default `1`) — tolak presensi jika `is_mock_location = true`
- `reject_outside_radius` (default `1`) — tolak presensi jika di luar radius geofence
- `max_gps_accuracy_meters` (default `50`) — tolak jika akurasi GPS lebih buruk dari nilai ini

Admin dapat mengubah nilai-nilai ini per perusahaan (akan dibuatkan UI-nya di
Web Admin Panel pada Fase 3).

## Catatan untuk Flutter

- Gunakan package `geolocator` — properti `Position.isMocked` (Android) untuk
  mengisi field `is_mock_location`, dan `Position.accuracy` untuk `accuracy`.
- Selfie wajib diambil dari kamera langsung (bukan galeri) — gunakan `camera`
  atau `image_picker` dengan `source: ImageSource.camera`.
- Semua request ke endpoint terlindungi harus menyertakan header:
  `Authorization: Bearer {token}` dan `Accept: application/json`.
- Endpoint check-in/check-out menggunakan `multipart/form-data` karena ada file upload.

## Langkah Berikutnya (Fase 3)

- Web Admin Panel (disarankan: Filament) sesuai mockup dashboard:
  - Resource: Employee, Department, Division, Location, Shift, WorkSchedule
  - Halaman approval Leave Request (menggunakan controller `LeaveApprovalController`
    sebagai referensi logika, diadaptasi ke Filament Action)
  - Halaman Setting per company (toggle require_selfie, radius default, dll)
  - Dashboard widget statistik (sesuai mockup)
- Modul laporan PDF/Excel/CSV (`barryvdh/laravel-dompdf`, `maatwebsite/excel`)

---

# Fase 3: Web Admin Panel (Filament) — Sudah Diimplementasikan

## Setup

1. Install Filament v3 & package pendukung:
   ```bash
   composer require filament/filament:"^3.0"
   composer require barryvdh/laravel-dompdf maatwebsite/excel
   php artisan filament:install --panels
   ```

2. Buat user admin pertama (jika belum ada dari Fase 1):
   ```bash
   php artisan tinker
   ```
   ```php
   \App\Models\User::create([
       'company_id' => 1,
       'name' => 'Admin Perusahaan',
       'email' => 'admin@contoh.com',
       'password' => bcrypt('password'),
       'role' => 'admin',
   ]);
   ```

3. Tambahkan `routes/reports.php` ke `bootstrap/app.php` (Laravel 11):
   ```php
   ->withRouting(
       web: __DIR__.'/../routes/web.php',
       api: __DIR__.'/../routes/api.php',
       commands: __DIR__.'/../routes/console.php',
       then: function () {
           Route::middleware('web')->group(base_path('routes/reports.php'));
       },
   )
   ```

4. Pastikan `AdminPanelProvider` terdaftar di `bootstrap/providers.php`:
   ```php
   return [
       App\Providers\AppServiceProvider::class,
       App\Providers\Filament\AdminPanelProvider::class,
   ];
   ```

5. Akses panel di `/admin` dan login dengan akun admin di atas.

## Struktur Menu Admin Panel

| Grup Menu | Resource/Page | Keterangan |
|---|---|---|
| Manajemen Karyawan | Karyawan (`EmployeeResource`) | CRUD lengkap, foto, import/export Excel, otomatis membuat akun login mobile |
| Manajemen Karyawan | Departemen, Divisi | Master data |
| Pengaturan Presensi | Lokasi/Cabang (`LocationResource`) | Titik koordinat + radius geofence, dengan preview peta (Leaflet) |
| Pengaturan Presensi | Shift Kerja (`ShiftResource`) | Jam masuk/keluar, toleransi telat & pulang awal |
| Pengaturan Presensi | Jadwal Kerja (`WorkScheduleResource`) | Penjadwalan per karyawan, + tombol "Generate Jadwal Mingguan" |
| Pengaturan Presensi | Pengaturan Presensi (`CompanySettings`) | Toggle wajib selfie, tolak fake GPS, tolak di luar radius, max akurasi GPS |
| Pengajuan | Cuti, Izin & Lembur (`LeaveRequestResource`) | Approve/Reject langsung dari tabel, badge jumlah pending di sidebar |
| Laporan | Presensi (`AttendanceResource`) | Read-only, filter tanggal/karyawan/status, export PDF/Excel/CSV |

## Dashboard

Tiga widget sesuai mockup yang telah disepakati:
- `AttendanceStatsOverview` — 4 kartu: hadir hari ini, terlambat, izin/sakit, tidak hadir
- `AttendanceTrendChart` — grafik batang tren kehadiran 7 hari terakhir
- `PendingLeaveRequests` — daftar 5 pengajuan terbaru yang menunggu approval

## Import Excel Karyawan

Format kolom (heading baris pertama, huruf kecil & underscore):

```
kode_karyawan | nama | email | no_hp | departemen | divisi | lokasi | jabatan | status_kepegawaian | tanggal_masuk | status
```

Jika `departemen`, `divisi`, atau `lokasi` belum ada, sistem akan membuatnya otomatis
(lokasi baru dibuat dengan radius default 100m & koordinat 0,0 — perlu diedit manual).

## Export Laporan

Tiga tombol export tersedia di halaman Laporan > Presensi, mengikuti filter yang aktif
(tanggal, karyawan, status):
- **PDF** — `barryvdh/laravel-dompdf`, layout landscape A4
- **Excel** — `maatwebsite/excel`, format `.xlsx`
- **CSV** — `maatwebsite/excel`, format `.csv`

## Langkah Berikutnya (Fase 4–6)

- **Fase 4**: Subscription & Payment — halaman billing per company, integrasi
  payment gateway (Midtrans/Xendit), webhook untuk update `subscription_status`
- **Fase 5**: Super Admin Panel — panel Filament terpisah (`/super-admin`) untuk
  mengelola seluruh tenant, paket subscription, dan monitoring pembayaran lintas company
- **Fase 6**: Mobile App Flutter — struktur project, screen login, check-in
  (sesuai mockup), riwayat presensi, dan pengajuan cuti/izin/sakit/lembur/wfh/wfa

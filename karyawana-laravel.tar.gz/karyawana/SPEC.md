# Karyawana — Spesifikasi Teknis

Sistem HR & Attendance berbasis SaaS Multi-Tenant: Web Admin (Laravel) + Mobile (Flutter).

## 1. Arsitektur Umum

- **Backend**: Laravel 11 (REST API untuk Flutter + Web Admin Panel/Blade atau Filament/Livewire)
- **Mobile**: Flutter (Android, dapat diperluas ke iOS)
- **Database**: MySQL/PostgreSQL — single database, isolasi data per perusahaan via kolom `company_id` (multi-tenant column-based)
- **Storage**: foto selfie & lampiran disimpan di disk lokal/S3 (`storage/app/public`)
- **Auth**: Laravel Sanctum (token API untuk Flutter), Laravel session untuk Web Admin
- **Role**: `super_admin` (kelola seluruh tenant/SaaS), `admin` (HR/pemilik perusahaan), `employee` (karyawan via mobile)

## 2. Struktur Multi-Tenant

Setiap tabel data operasional memiliki kolom `company_id` (foreign key ke tabel `companies`).
Digunakan **Global Scope** (`BelongsToCompany` trait) agar query otomatis terfilter sesuai
`company_id` user yang login — kecuali untuk `super_admin` yang bisa melihat semua tenant.

```
User login -> ambil company_id dari session/token -> Global Scope filter semua query model tenant
```

## 3. Modul & Fitur

### 3.1 Super Admin Panel
- Kelola daftar perusahaan (tenant): aktivasi, suspend, hapus
- Kelola paket subscription (Basic/Pro/Enterprise) — harga, max karyawan, fitur
- Monitoring pembayaran & status subscription tiap tenant
- Statistik global (jumlah tenant, revenue, growth)

### 3.2 Web Admin (per perusahaan)
- Dashboard statistik: kehadiran hari ini, terlambat, izin/cuti pending, grafik bulanan
- Manajemen Karyawan: CRUD, import/export Excel/CSV, foto profil
- Departemen & Divisi
- Lokasi/Cabang (titik koordinat + radius geofence)
- Shift & Jadwal Kerja (mingguan, multi-shift, toleransi telat/pulang awal)
- Approval Pengajuan: Cuti, Izin, Sakit, Lembur, WFH, WFA
- Laporan: rekap kehadiran, export PDF/Excel/CSV
- Pengaturan tenant: wajib selfie on/off, radius default, toleransi GPS accuracy
- Manajemen Subscription & Pembayaran (lihat status paket, upgrade, riwayat invoice)

### 3.3 Mobile App (Flutter)
- Login (multi-tenant aware — pilih/terdeteksi dari email)
- Check-in / check-out dengan:
  - GPS capture (lat, lng, accuracy)
  - Validasi radius geofence terhadap lokasi kantor
  - Deteksi fake GPS / mock location (via platform channel: `Settings.Secure.ALLOW_MOCK_LOCATION` / GPS provider check + library seperti `safe_device` / `mock_location_detector`)
  - Selfie wajib/opsional (kamera native, bukan galeri)
- Lihat jadwal & shift pribadi
- Riwayat kehadiran pribadi
- Pengajuan: Cuti, Izin, Sakit, Lembur, WFH, WFA (dengan lampiran)
- Notifikasi push (Firebase Cloud Messaging): approval status, reminder absen, pengumuman
- Profil & ganti password

## 4. Skema Database (Ringkasan)

| Tabel | Keterangan |
|---|---|
| `subscription_plans` | Master paket SaaS |
| `companies` | Data tenant/perusahaan |
| `subscriptions` | Riwayat & status subscription per company |
| `payments` | Transaksi pembayaran |
| `users` | Akun login (super_admin/admin/employee) |
| `departments` | Departemen per company |
| `divisions` | Divisi (anak dari department) |
| `locations` | Cabang/lokasi + koordinat & radius geofence |
| `employees` | Data karyawan lengkap |
| `shifts` | Master shift kerja |
| `work_schedules` | Penjadwalan shift per karyawan per tanggal |
| `attendances` | Data presensi harian (check-in/out, GPS, selfie) |
| `leave_requests` | Pengajuan cuti/izin/sakit/lembur/wfh/wfa |
| `settings` | Konfigurasi per company (wajib selfie, toleransi, dsb) |

Detail kolom: lihat file migration di `database/migrations/`.

## 5. Deteksi Fake GPS & Mock Location (Flutter)

- Cek `LocationAccuracyStatus` & flag `isMockLocation` dari plugin (`geolocator` mendukung
  pengecekan `isMocked` pada Android melalui `Position.isMocked`)
- Simpan flag `is_mock_location` & `gps_accuracy` ke tabel `attendances`
- Backend dapat menolak/menandai presensi jika `is_mock_location = true` atau
  `gps_accuracy > threshold` (dikonfigurasi di `settings`)

## 6. Roadmap Pengembangan

1. **Fase 1 (ini)**: Database schema + model inti + struktur multi-tenant
2. **Fase 2**: Auth (Sanctum) + API endpoint untuk Flutter (attendance, leave request, profile)
3. **Fase 3**: Web Admin Panel (Filament/Livewire) — CRUD karyawan, jadwal, approval
4. **Fase 4**: Modul laporan (PDF/Excel/CSV) — menggunakan `barryvdh/laravel-dompdf` &
   `maatwebsite/excel`
5. **Fase 5**: Subscription & Payment (integrasi payment gateway: Midtrans/Xendit)
6. **Fase 6**: Super Admin Panel
7. **Fase 7**: Flutter mobile app — auth, GPS attendance, selfie, pengajuan, notifikasi FCM

## 7. Catatan Implementasi

- Gunakan `spatie/laravel-permission` untuk role & permission granular jika dibutuhkan lebih
  detail dari sekadar 3 role dasar.
- Notifikasi mobile menggunakan Firebase Cloud Messaging (FCM) — token device disimpan di
  tabel `users` (kolom `fcm_token`).
- Semua waktu disimpan dalam UTC, dikonversi ke timezone perusahaan saat ditampilkan
  (tambahkan kolom `timezone` di `companies`).

<?php

namespace App\Models;

use App\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class WorkSchedule extends Model
{
    use BelongsToCompany;

    protected $fillable = [
        'company_id', 'employee_id', 'shift_id', 'location_id', 'date', 'is_day_off',
    ];

    protected $casts = [
        'date' => 'date',
        'is_day_off' => 'boolean',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function shift()
    {
        return $this->belongsTo(Shift::class);
    }

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    public function attendance()
    {
        return $this->hasOne(Attendance::class);
    }
}

<?php

namespace App\Models;

use App\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    use BelongsToCompany;

    protected $fillable = [
        'company_id', 'name', 'start_time', 'end_time', 'is_overnight',
        'late_tolerance_minutes', 'early_leave_tolerance_minutes', 'is_active',
    ];

    protected $casts = [
        'is_overnight' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function workSchedules()
    {
        return $this->hasMany(WorkSchedule::class);
    }

    public function attendances()
    {
        return $this->hasMany(Attendance::class);
    }
}

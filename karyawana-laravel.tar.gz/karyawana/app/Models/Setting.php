<?php

namespace App\Models;

use App\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    use BelongsToCompany;

    protected $fillable = ['company_id', 'key', 'value'];

    /**
     * Ambil nilai setting untuk company tertentu, dengan default jika belum diset.
     */
    public static function getValue(int $companyId, string $key, $default = null)
    {
        $setting = static::allCompanies()
            ->where('company_id', $companyId)
            ->where('key', $key)
            ->first();

        return $setting?->value ?? $default;
    }

    public static function setValue(int $companyId, string $key, $value): void
    {
        static::allCompanies()->updateOrCreate(
            ['company_id' => $companyId, 'key' => $key],
            ['value' => $value]
        );
    }
}

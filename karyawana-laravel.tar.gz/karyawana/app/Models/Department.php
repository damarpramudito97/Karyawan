<?php

namespace App\Models;

use App\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use BelongsToCompany;

    protected $fillable = ['company_id', 'name', 'code', 'description'];

    public function divisions()
    {
        return $this->hasMany(Division::class);
    }

    public function employees()
    {
        return $this->hasMany(Employee::class);
    }
}

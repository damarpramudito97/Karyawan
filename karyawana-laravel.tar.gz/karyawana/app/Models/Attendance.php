<?php

namespace App\Models;

use App\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    use BelongsToCompany;

    protected $fillable = [
        'company_id', 'employee_id', 'work_schedule_id', 'shift_id', 'location_id', 'date',
        'check_in_at', 'check_in_lat', 'check_in_lng', 'check_in_accuracy', 'check_in_address',
        'check_in_photo', 'check_in_is_mock_location', 'check_in_distance_meters', 'check_in_within_radius',
        'check_out_at', 'check_out_lat', 'check_out_lng', 'check_out_accuracy', 'check_out_address',
        'check_out_photo', 'check_out_is_mock_location', 'check_out_distance_meters', 'check_out_within_radius',
        'late_minutes', 'early_leave_minutes', 'overtime_minutes', 'status', 'notes',
    ];

    protected $casts = [
        'date' => 'date',
        'check_in_at' => 'datetime',
        'check_out_at' => 'datetime',
        'check_in_is_mock_location' => 'boolean',
        'check_out_is_mock_location' => 'boolean',
        'check_in_within_radius' => 'boolean',
        'check_out_within_radius' => 'boolean',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function workSchedule()
    {
        return $this->belongsTo(WorkSchedule::class);
    }

    public function shift()
    {
        return $this->belongsTo(Shift::class);
    }

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    /**
     * Hitung keterlambatan (menit) berdasarkan waktu check-in & shift.
     */
    public function calculateLateMinutes(): int
    {
        if (! $this->check_in_at || ! $this->shift) {
            return 0;
        }

        $shiftStart = $this->date->copy()->setTimeFromTimeString($this->shift->start_time);
        $tolerance = $this->shift->late_tolerance_minutes;

        $diffMinutes = $shiftStart->diffInMinutes($this->check_in_at, false);

        return $diffMinutes > $tolerance ? $diffMinutes - $tolerance : 0;
    }

    /**
     * Hitung pulang awal (menit) berdasarkan waktu check-out & shift.
     */
    public function calculateEarlyLeaveMinutes(): int
    {
        if (! $this->check_out_at || ! $this->shift) {
            return 0;
        }

        $shiftEnd = $this->date->copy()->setTimeFromTimeString($this->shift->end_time);
        $tolerance = $this->shift->early_leave_tolerance_minutes;

        $diffMinutes = $this->check_out_at->diffInMinutes($shiftEnd, false);

        return $diffMinutes > $tolerance ? $diffMinutes - $tolerance : 0;
    }
}

<?php

namespace App\Console\Commands;

use App\Models\Company;
use Illuminate\Console\Command;

class CheckExpiredSubscriptions extends Command
{
    protected $signature = 'subscriptions:check-expired';

    protected $description = 'Tandai company dengan subscription/trial yang sudah berakhir sebagai expired';

    public function handle(): void
    {
        $today = now()->toDateString();

        $trialExpired = Company::where('subscription_status', 'trial')
            ->whereDate('trial_ends_at', '<', $today)
            ->update(['subscription_status' => 'expired']);

        $subscriptionExpired = Company::where('subscription_status', 'active')
            ->whereDate('subscription_ends_at', '<', $today)
            ->update(['subscription_status' => 'expired']);

        $this->info("Trial expired: {$trialExpired}, Subscription expired: {$subscriptionExpired}");
    }
}

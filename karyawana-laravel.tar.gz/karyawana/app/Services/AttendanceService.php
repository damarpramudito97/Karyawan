<?php

namespace App\Services;

use App\Models\Attendance;
use App\Models\Employee;
use App\Models\Location;
use App\Models\Setting;
use App\Models\WorkSchedule;
use Carbon\Carbon;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class AttendanceService
{
    /**
     * Proses check-in karyawan.
     *
     * @param  array{lat: float, lng: float, accuracy: float, is_mock_location: bool}  $gps
     */
    public function checkIn(Employee $employee, array $gps, ?UploadedFile $selfie, ?string $notes = null): Attendance
    {
        $today = Carbon::today();
        $companyId = $employee->company_id;

        $schedule = WorkSchedule::allCompanies()
            ->where('employee_id', $employee->id)
            ->whereDate('date', $today)
            ->first();

        if ($schedule && $schedule->is_day_off) {
            throw ValidationException::withMessages([
                'date' => 'Hari ini adalah hari libur sesuai jadwal Anda.',
            ]);
        }

        $attendance = Attendance::allCompanies()
            ->where('employee_id', $employee->id)
            ->whereDate('date', $today)
            ->first();

        if ($attendance && $attendance->check_in_at) {
            throw ValidationException::withMessages([
                'check_in' => 'Anda sudah melakukan check-in hari ini.',
            ]);
        }

        $location = $schedule?->location ?? $employee->location;
        $shift = $schedule?->shift;

        $this->validateGps($companyId, $gps);

        $distance = null;
        $withinRadius = true;

        if ($location) {
            $distance = round($location->distanceTo($gps['lat'], $gps['lng']), 2);
            $withinRadius = $location->isWithinRadius($gps['lat'], $gps['lng']);

            $rejectOutside = (bool) Setting::getValue($companyId, 'reject_outside_radius', true);

            if (! $withinRadius && $rejectOutside) {
                throw ValidationException::withMessages([
                    'location' => "Anda berada di luar radius lokasi kantor ({$distance} meter dari titik yang ditentukan).",
                ]);
            }
        }

        $photoPath = $this->storeSelfie($companyId, $employee->id, $selfie, 'check_in');

        $now = Carbon::now();

        $attendance = $attendance ?: new Attendance([
            'company_id' => $companyId,
            'employee_id' => $employee->id,
            'date' => $today,
        ]);

        $attendance->fill([
            'work_schedule_id' => $schedule?->id,
            'shift_id' => $shift?->id,
            'location_id' => $location?->id,
            'check_in_at' => $now,
            'check_in_lat' => $gps['lat'],
            'check_in_lng' => $gps['lng'],
            'check_in_accuracy' => $gps['accuracy'],
            'check_in_photo' => $photoPath,
            'check_in_is_mock_location' => $gps['is_mock_location'],
            'check_in_distance_meters' => $distance,
            'check_in_within_radius' => $withinRadius,
            'status' => 'present',
            'notes' => $notes,
        ]);

        $attendance->save();

        if ($shift) {
            $attendance->late_minutes = $attendance->calculateLateMinutes();
            if ($attendance->late_minutes > 0) {
                $attendance->status = 'late';
            }
            $attendance->save();
        }

        return $attendance->refresh();
    }

    /**
     * Proses check-out karyawan.
     *
     * @param  array{lat: float, lng: float, accuracy: float, is_mock_location: bool}  $gps
     */
    public function checkOut(Employee $employee, array $gps, ?UploadedFile $selfie, ?string $notes = null): Attendance
    {
        $today = Carbon::today();
        $companyId = $employee->company_id;

        $attendance = Attendance::allCompanies()
            ->where('employee_id', $employee->id)
            ->whereDate('date', $today)
            ->first();

        if (! $attendance || ! $attendance->check_in_at) {
            throw ValidationException::withMessages([
                'check_in' => 'Anda belum melakukan check-in hari ini.',
            ]);
        }

        if ($attendance->check_out_at) {
            throw ValidationException::withMessages([
                'check_out' => 'Anda sudah melakukan check-out hari ini.',
            ]);
        }

        $this->validateGps($companyId, $gps);

        $location = $attendance->location;
        $distance = null;
        $withinRadius = true;

        if ($location) {
            $distance = round($location->distanceTo($gps['lat'], $gps['lng']), 2);
            $withinRadius = $location->isWithinRadius($gps['lat'], $gps['lng']);
        }

        $photoPath = $this->storeSelfie($companyId, $employee->id, $selfie, 'check_out');

        $attendance->fill([
            'check_out_at' => Carbon::now(),
            'check_out_lat' => $gps['lat'],
            'check_out_lng' => $gps['lng'],
            'check_out_accuracy' => $gps['accuracy'],
            'check_out_photo' => $photoPath,
            'check_out_is_mock_location' => $gps['is_mock_location'],
            'check_out_distance_meters' => $distance,
            'check_out_within_radius' => $withinRadius,
        ]);

        if ($attendance->shift) {
            $attendance->early_leave_minutes = $attendance->calculateEarlyLeaveMinutes();

            $shiftEnd = $attendance->date->copy()->setTimeFromTimeString($attendance->shift->end_time);
            $overtime = $shiftEnd->diffInMinutes($attendance->check_out_at, false);
            $attendance->overtime_minutes = $overtime > 0 ? $overtime : 0;
        }

        if ($notes) {
            $attendance->notes = trim(($attendance->notes ?? '') . ' ' . $notes);
        }

        $attendance->save();

        return $attendance->refresh();
    }

    /**
     * Validasi akurasi GPS & mock location berdasarkan setting perusahaan.
     */
    protected function validateGps(int $companyId, array $gps): void
    {
        $rejectMock = (bool) Setting::getValue($companyId, 'reject_mock_location', true);
        $maxAccuracy = (float) Setting::getValue($companyId, 'max_gps_accuracy_meters', 50);

        if ($rejectMock && ($gps['is_mock_location'] ?? false)) {
            throw ValidationException::withMessages([
                'gps' => 'Terdeteksi penggunaan lokasi palsu (fake GPS/mock location). Presensi ditolak.',
            ]);
        }

        if (! empty($gps['accuracy']) && $gps['accuracy'] > $maxAccuracy) {
            throw ValidationException::withMessages([
                'gps' => "Akurasi GPS terlalu rendah ({$gps['accuracy']} m). Pastikan GPS aktif dan sinyal baik, lalu coba lagi.",
            ]);
        }
    }

    /**
     * Simpan foto selfie ke storage, dengan validasi wajib/opsional sesuai setting.
     */
    protected function storeSelfie(int $companyId, int $employeeId, ?UploadedFile $selfie, string $type): ?string
    {
        $requireSelfie = (bool) Setting::getValue($companyId, 'require_selfie', true);

        if (! $selfie) {
            if ($requireSelfie) {
                throw ValidationException::withMessages([
                    'selfie' => 'Foto selfie wajib diisi.',
                ]);
            }

            return null;
        }

        $filename = sprintf(
            '%s_%s_%s.%s',
            $type,
            now()->format('Ymd_His'),
            $employeeId,
            $selfie->getClientOriginalExtension() ?: 'jpg'
        );

        $path = "attendance-selfies/{$companyId}/{$employeeId}";

        return $selfie->storeAs($path, $filename, 'public');
    }
}

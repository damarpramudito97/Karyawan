<?php

namespace App\Services;

use App\Models\Company;
use App\Models\Payment;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Integrasi Midtrans Snap (https://snap-docs.midtrans.com/).
 *
 * Env yang dibutuhkan:
 *   MIDTRANS_SERVER_KEY=
 *   MIDTRANS_CLIENT_KEY=
 *   MIDTRANS_IS_PRODUCTION=false
 */
class MidtransService
{
    protected string $baseUrl;

    public function __construct()
    {
        $isProduction = config('services.midtrans.is_production', false);

        $this->baseUrl = $isProduction
            ? 'https://app.midtrans.com/snap/v1'
            : 'https://app.sandbox.midtrans.com/snap/v1';
    }

    /**
     * Buat transaksi baru untuk upgrade/perpanjangan subscription.
     * Mengembalikan snap_token & redirect_url untuk dibuka di WebView/browser.
     */
    public function createTransaction(Company $company, SubscriptionPlan $plan): array
    {
        $invoiceNumber = 'INV-' . now()->format('Ymd') . '-' . Str::upper(Str::random(6));

        $payload = [
            'transaction_details' => [
                'order_id' => $invoiceNumber,
                'gross_amount' => $plan->price,
            ],
            'customer_details' => [
                'first_name' => $company->name,
                'email' => $company->email,
                'phone' => $company->phone,
            ],
            'item_details' => [[
                'id' => (string) $plan->id,
                'price' => $plan->price,
                'quantity' => 1,
                'name' => "Paket {$plan->name} ({$plan->billing_cycle})",
            ]],
        ];

        $response = Http::withBasicAuth(config('services.midtrans.server_key'), '')
            ->acceptJson()
            ->post("{$this->baseUrl}/transactions", $payload)
            ->throw()
            ->json();

        // Buat record subscription (pending) & payment (pending)
        $subscription = Subscription::create([
            'company_id' => $company->id,
            'subscription_plan_id' => $plan->id,
            'starts_at' => now(),
            'ends_at' => $plan->billing_cycle === 'yearly'
                ? now()->addYear()
                : now()->addMonth(),
            'status' => 'pending',
            'price' => $plan->price,
        ]);

        Payment::create([
            'company_id' => $company->id,
            'subscription_id' => $subscription->id,
            'invoice_number' => $invoiceNumber,
            'amount' => $plan->price,
            'currency' => 'IDR',
            'payment_gateway' => 'midtrans',
            'status' => 'pending',
        ]);

        return [
            'snap_token' => $response['token'],
            'redirect_url' => $response['redirect_url'],
            'invoice_number' => $invoiceNumber,
        ];
    }

    /**
     * Proses notifikasi/webhook dari Midtrans.
     * Dokumentasi: https://docs.midtrans.com/docs/https-notification-webhooks
     */
    public function handleNotification(array $payload): void
    {
        $orderId = $payload['order_id'];
        $transactionStatus = $payload['transaction_status'];
        $fraudStatus = $payload['fraud_status'] ?? null;

        $payment = Payment::where('invoice_number', $orderId)->first();

        if (! $payment) {
            return;
        }

        $payment->update([
            'transaction_id' => $payload['transaction_id'] ?? null,
            'payment_method' => $payload['payment_type'] ?? null,
            'gateway_response' => $payload,
        ]);

        $isSuccess = in_array($transactionStatus, ['capture', 'settlement'])
            && ($fraudStatus === null || $fraudStatus === 'accept');

        if ($isSuccess) {
            $this->markAsPaid($payment);
        } elseif (in_array($transactionStatus, ['deny', 'cancel', 'expire'])) {
            $payment->update(['status' => $transactionStatus === 'expire' ? 'expired' : 'failed']);

            $payment->subscription?->update(['status' => 'cancelled']);
        }
    }

    protected function markAsPaid(Payment $payment): void
    {
        $payment->update([
            'status' => 'paid',
            'paid_at' => now(),
        ]);

        $subscription = $payment->subscription;

        if (! $subscription) {
            return;
        }

        $subscription->update(['status' => 'active']);

        $company = $subscription->company;

        $company->update([
            'subscription_plan_id' => $subscription->subscription_plan_id,
            'subscription_status' => 'active',
            'subscription_ends_at' => $subscription->ends_at,
        ]);
    }
}

<?php

namespace App\Exports;

use App\Models\Attendance;
use Illuminate\Support\Carbon;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class AttendanceExport implements FromCollection, WithHeadings, WithMapping
{
    public function __construct(protected array $filters = [])
    {
    }

    public function collection()
    {
        $query = Attendance::with(['employee', 'shift', 'location'])
            ->orderBy('date')
            ->orderBy('employee_id');

        if (! empty($this->filters['from'])) {
            $query->whereDate('date', '>=', $this->filters['from']);
        }

        if (! empty($this->filters['until'])) {
            $query->whereDate('date', '<=', $this->filters['until']);
        }

        if (! empty($this->filters['employee_id'])) {
            $query->where('employee_id', $this->filters['employee_id']);
        }

        if (! empty($this->filters['status'])) {
            $query->where('status', $this->filters['status']);
        }

        return $query->get();
    }

    public function headings(): array
    {
        return [
            'Tanggal', 'Karyawan', 'Shift', 'Lokasi', 'Check-in', 'Check-out',
            'Telat (menit)', 'Pulang Awal (menit)', 'Lembur (menit)', 'Status', 'Fake GPS Saat Check-in',
        ];
    }

    public function map($attendance): array
    {
        return [
            $attendance->date->format('Y-m-d'),
            $attendance->employee->name,
            $attendance->shift?->name,
            $attendance->location?->name,
            $attendance->check_in_at?->format('H:i:s'),
            $attendance->check_out_at?->format('H:i:s'),
            $attendance->late_minutes,
            $attendance->early_leave_minutes,
            $attendance->overtime_minutes,
            $attendance->status,
            $attendance->check_in_is_mock_location ? 'Ya' : 'Tidak',
        ];
    }
}

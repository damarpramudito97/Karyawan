<?php

namespace App\Exports;

use App\Models\Employee;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class EmployeesExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return Employee::with(['department', 'division', 'location'])->get();
    }

    public function headings(): array
    {
        return [
            'Kode Karyawan', 'Nama', 'Email', 'No. HP', 'Departemen', 'Divisi',
            'Lokasi', 'Jabatan', 'Status Kepegawaian', 'Tanggal Masuk', 'Status',
        ];
    }

    public function map($employee): array
    {
        return [
            $employee->employee_code,
            $employee->name,
            $employee->email,
            $employee->phone,
            $employee->department?->name,
            $employee->division?->name,
            $employee->location?->name,
            $employee->position,
            $employee->employment_status,
            $employee->join_date?->format('Y-m-d'),
            $employee->status,
        ];
    }
}

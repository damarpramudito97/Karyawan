<?php

namespace App\Imports;

use App\Models\Department;
use App\Models\Division;
use App\Models\Employee;
use App\Models\Location;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

/**
 * Format kolom Excel yang diharapkan (heading di baris pertama):
 * kode_karyawan | nama | email | no_hp | departemen | divisi | lokasi | jabatan |
 * status_kepegawaian | tanggal_masuk | status
 */
class EmployeesImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row): ?Employee
    {
        $companyId = auth()->user()->company_id;

        $department = $this->findOrCreate(Department::class, $row['departemen'] ?? null, $companyId);
        $division = $this->findOrCreate(Division::class, $row['divisi'] ?? null, $companyId, [
            'department_id' => $department?->id,
        ]);
        $location = $this->findOrCreate(Location::class, $row['lokasi'] ?? null, $companyId, [
            'latitude' => 0,
            'longitude' => 0,
            'radius_meters' => 100,
        ]);

        return new Employee([
            'company_id' => $companyId,
            'employee_code' => $row['kode_karyawan'] ?? null,
            'name' => $row['nama'],
            'email' => $row['email'] ?? null,
            'phone' => $row['no_hp'] ?? null,
            'department_id' => $department?->id,
            'division_id' => $division?->id,
            'location_id' => $location?->id,
            'position' => $row['jabatan'] ?? null,
            'employment_status' => $row['status_kepegawaian'] ?? 'permanent',
            'join_date' => $row['tanggal_masuk'] ?? null,
            'status' => $row['status'] ?? 'active',
        ]);
    }

    public function rules(): array
    {
        return [
            'nama' => 'required|string|max:255',
            'email' => 'nullable|email',
        ];
    }

    /**
     * Cari record master (department/division/location) berdasarkan nama,
     * buat baru jika belum ada (agar import tidak gagal karena data master kurang).
     */
    protected function findOrCreate(string $modelClass, ?string $name, int $companyId, array $extra = [])
    {
        if (! $name) {
            return null;
        }

        return $modelClass::allCompanies()
            ->where('company_id', $companyId)
            ->where('name', $name)
            ->first()
            ?? $modelClass::create(array_merge([
                'company_id' => $companyId,
                'name' => $name,
            ], $extra));
    }
}

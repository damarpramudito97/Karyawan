<?php

namespace App\Traits;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * Trait ini diterapkan pada model-model yang datanya terpisah per perusahaan
 * (multi-tenant berbasis kolom company_id).
 *
 * - Otomatis menambahkan filter company_id = current tenant pada setiap query,
 *   KECUALI untuk user dengan role super_admin.
 * - Otomatis mengisi company_id saat record baru dibuat.
 */
trait BelongsToCompany
{
    protected static function bootBelongsToCompany(): void
    {
        // Filter otomatis berdasarkan tenant aktif
        static::addGlobalScope('company', function (Builder $builder) {
            $user = auth()->user();

            if ($user && $user->role !== 'super_admin' && $user->company_id) {
                $builder->where(
                    $builder->getModel()->getTable() . '.company_id',
                    $user->company_id
                );
            }
        });

        // Isi otomatis company_id saat membuat record baru
        static::creating(function (Model $model) {
            $user = auth()->user();

            if (! $model->company_id && $user && $user->company_id) {
                $model->company_id = $user->company_id;
            }
        });
    }

    public function company()
    {
        return $this->belongsTo(\App\Models\Company::class);
    }

    /**
     * Scope untuk mengabaikan filter tenant (digunakan oleh super_admin
     * atau proses background/queue yang tidak punya auth user).
     */
    public function scopeAllCompanies(Builder $query): Builder
    {
        return $query->withoutGlobalScope('company');
    }
}

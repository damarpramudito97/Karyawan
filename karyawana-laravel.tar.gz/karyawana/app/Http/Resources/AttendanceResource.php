<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AttendanceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'date' => $this->date->format('Y-m-d'),
            'status' => $this->status,
            'shift' => $this->shift ? [
                'id' => $this->shift->id,
                'name' => $this->shift->name,
                'start_time' => $this->shift->start_time,
                'end_time' => $this->shift->end_time,
            ] : null,
            'location' => $this->location ? [
                'id' => $this->location->id,
                'name' => $this->location->name,
            ] : null,
            'check_in' => $this->check_in_at ? [
                'time' => $this->check_in_at->format('Y-m-d H:i:s'),
                'photo_url' => $this->check_in_photo ? asset('storage/' . $this->check_in_photo) : null,
                'latitude' => (float) $this->check_in_lat,
                'longitude' => (float) $this->check_in_lng,
                'accuracy' => (float) $this->check_in_accuracy,
                'distance_meters' => $this->check_in_distance_meters !== null ? (float) $this->check_in_distance_meters : null,
                'within_radius' => (bool) $this->check_in_within_radius,
                'is_mock_location' => (bool) $this->check_in_is_mock_location,
            ] : null,
            'check_out' => $this->check_out_at ? [
                'time' => $this->check_out_at->format('Y-m-d H:i:s'),
                'photo_url' => $this->check_out_photo ? asset('storage/' . $this->check_out_photo) : null,
                'latitude' => (float) $this->check_out_lat,
                'longitude' => (float) $this->check_out_lng,
                'accuracy' => (float) $this->check_out_accuracy,
                'distance_meters' => $this->check_out_distance_meters !== null ? (float) $this->check_out_distance_meters : null,
                'within_radius' => (bool) $this->check_out_within_radius,
                'is_mock_location' => (bool) $this->check_out_is_mock_location,
            ] : null,
            'late_minutes' => $this->late_minutes,
            'early_leave_minutes' => $this->early_leave_minutes,
            'overtime_minutes' => $this->overtime_minutes,
            'notes' => $this->notes,
        ];
    }
}

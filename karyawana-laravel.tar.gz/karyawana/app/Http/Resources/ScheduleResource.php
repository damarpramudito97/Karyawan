<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ScheduleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'date' => $this->date->format('Y-m-d'),
            'is_day_off' => (bool) $this->is_day_off,
            'shift' => $this->shift ? [
                'id' => $this->shift->id,
                'name' => $this->shift->name,
                'start_time' => $this->shift->start_time,
                'end_time' => $this->shift->end_time,
                'is_overnight' => (bool) $this->shift->is_overnight,
            ] : null,
            'location' => $this->location ? [
                'id' => $this->location->id,
                'name' => $this->location->name,
                'latitude' => (float) $this->location->latitude,
                'longitude' => (float) $this->location->longitude,
                'radius_meters' => $this->location->radius_meters,
            ] : null,
        ];
    }
}

<?php

namespace App\Http\Requests\Attendance;

use Illuminate\Foundation\Http\FormRequest;

class CheckOutRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'accuracy' => ['required', 'numeric', 'min:0'],
            'is_mock_location' => ['required', 'boolean'],
            'selfie' => ['nullable', 'image', 'max:4096'],
            'notes' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function gpsData(): array
    {
        return [
            'lat' => (float) $this->input('latitude'),
            'lng' => (float) $this->input('longitude'),
            'accuracy' => (float) $this->input('accuracy'),
            'is_mock_location' => (bool) $this->input('is_mock_location'),
        ];
    }
}

<?php

namespace App\Http\Controllers\Report;

use App\Exports\AttendanceExport;
use App\Http\Controllers\Controller;
use App\Models\Attendance;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Excel as ExcelFormat;
use Maatwebsite\Excel\Facades\Excel;

class AttendanceReportController extends Controller
{
    /**
     * Ambil data presensi sesuai filter (sama dengan filter pada AttendanceResource).
     */
    protected function query(Request $request)
    {
        $query = Attendance::with(['employee', 'shift', 'location'])
            ->orderBy('date')
            ->orderBy('employee_id');

        if ($request->filled('date.from')) {
            $query->whereDate('date', '>=', $request->input('date.from'));
        }

        if ($request->filled('date.until')) {
            $query->whereDate('date', '<=', $request->input('date.until'));
        }

        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->input('employee_id'));
        }

        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        return $query;
    }

    public function pdf(Request $request)
    {
        $attendances = $this->query($request)->get();

        $pdf = Pdf::loadView('reports.attendance-pdf', [
            'attendances' => $attendances,
            'company' => $request->user()->company,
            'generatedAt' => now(),
        ])->setPaper('a4', 'landscape');

        return $pdf->download('rekap-presensi-' . now()->format('Ymd_His') . '.pdf');
    }

    public function excel(Request $request)
    {
        $filters = [
            'from' => $request->input('date.from'),
            'until' => $request->input('date.until'),
            'employee_id' => $request->input('employee_id'),
            'status' => $request->input('status'),
        ];

        return Excel::download(
            new AttendanceExport($filters),
            'rekap-presensi-' . now()->format('Ymd_His') . '.xlsx'
        );
    }

    public function csv(Request $request)
    {
        $filters = [
            'from' => $request->input('date.from'),
            'until' => $request->input('date.until'),
            'employee_id' => $request->input('employee_id'),
            'status' => $request->input('status'),
        ];

        return Excel::download(
            new AttendanceExport($filters),
            'rekap-presensi-' . now()->format('Ymd_His') . '.csv',
            ExcelFormat::CSV
        );
    }
}

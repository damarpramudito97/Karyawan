<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\LeaveRequestResource;
use App\Models\LeaveRequest;
use Illuminate\Http\Request;

class LeaveApprovalController extends Controller
{
    /**
     * Daftar pengajuan seluruh karyawan (untuk admin), default menunjukkan yang pending.
     */
    public function index(Request $request)
    {
        $query = LeaveRequest::with('employee')
            ->orderByDesc('created_at');

        $status = $request->input('status', 'pending');

        if ($status !== 'all') {
            $query->where('status', $status);
        }

        if ($request->filled('type')) {
            $query->where('type', $request->input('type'));
        }

        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->input('employee_id'));
        }

        return LeaveRequestResource::collection($query->paginate(20));
    }

    public function approve(Request $request, LeaveRequest $leaveRequest)
    {
        $request->validate(['notes' => ['nullable', 'string', 'max:500']]);

        $leaveRequest->approve($request->user(), $request->input('notes'));

        return response()->json([
            'message' => 'Pengajuan disetujui.',
            'data' => new LeaveRequestResource($leaveRequest),
        ]);
    }

    public function reject(Request $request, LeaveRequest $leaveRequest)
    {
        $request->validate(['notes' => ['required', 'string', 'max:500']]);

        $leaveRequest->reject($request->user(), $request->input('notes'));

        return response()->json([
            'message' => 'Pengajuan ditolak.',
            'data' => new LeaveRequestResource($leaveRequest),
        ]);
    }
}

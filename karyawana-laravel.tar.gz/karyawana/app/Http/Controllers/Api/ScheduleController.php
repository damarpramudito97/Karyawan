<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ScheduleResource;
use App\Models\WorkSchedule;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ScheduleController extends Controller
{
    /**
     * Jadwal hari ini.
     */
    public function today(Request $request)
    {
        $employee = $request->user()->employee;

        $schedule = WorkSchedule::allCompanies()
            ->where('employee_id', $employee->id)
            ->whereDate('date', Carbon::today())
            ->with(['shift', 'location'])
            ->first();

        return response()->json([
            'data' => $schedule ? new ScheduleResource($schedule) : null,
        ]);
    }

    /**
     * Jadwal satu minggu (default: minggu berjalan).
     */
    public function week(Request $request)
    {
        $employee = $request->user()->employee;

        $start = $request->filled('start')
            ? Carbon::parse($request->input('start'))->startOfDay()
            : Carbon::now()->startOfWeek();

        $end = $start->copy()->addDays(6);

        $schedules = WorkSchedule::allCompanies()
            ->where('employee_id', $employee->id)
            ->whereBetween('date', [$start->toDateString(), $end->toDateString()])
            ->with(['shift', 'location'])
            ->orderBy('date')
            ->get();

        return response()->json([
            'data' => ScheduleResource::collection($schedules),
        ]);
    }
}

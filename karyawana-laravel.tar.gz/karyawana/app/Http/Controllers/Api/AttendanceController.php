<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Attendance\CheckInRequest;
use App\Http\Requests\Attendance\CheckOutRequest;
use App\Http\Resources\AttendanceResource;
use App\Models\Attendance;
use App\Services\AttendanceService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function __construct(protected AttendanceService $service)
    {
    }

    /**
     * Status presensi hari ini (untuk ditampilkan di home screen).
     */
    public function today(Request $request)
    {
        $employee = $request->user()->employee;

        $attendance = Attendance::allCompanies()
            ->where('employee_id', $employee->id)
            ->whereDate('date', Carbon::today())
            ->with(['shift', 'location'])
            ->first();

        return response()->json([
            'data' => $attendance ? new AttendanceResource($attendance) : null,
        ]);
    }

    /**
     * Riwayat presensi (paginated, filter by month).
     */
    public function history(Request $request)
    {
        $employee = $request->user()->employee;

        $month = $request->input('month', Carbon::now()->format('Y-m'));

        $query = Attendance::allCompanies()
            ->where('employee_id', $employee->id)
            ->with(['shift', 'location'])
            ->whereRaw("DATE_FORMAT(date, '%Y-%m') = ?", [$month])
            ->orderByDesc('date');

        $attendances = $query->paginate(31);

        return AttendanceResource::collection($attendances);
    }

    public function checkIn(CheckInRequest $request)
    {
        $employee = $request->user()->employee;

        $attendance = $this->service->checkIn(
            $employee,
            $request->gpsData(),
            $request->file('selfie'),
            $request->input('notes')
        );

        return response()->json([
            'message' => 'Check-in berhasil.',
            'data' => new AttendanceResource($attendance),
        ]);
    }

    public function checkOut(CheckOutRequest $request)
    {
        $employee = $request->user()->employee;

        $attendance = $this->service->checkOut(
            $employee,
            $request->gpsData(),
            $request->file('selfie'),
            $request->input('notes')
        );

        return response()->json([
            'message' => 'Check-out berhasil.',
            'data' => new AttendanceResource($attendance),
        ]);
    }
}

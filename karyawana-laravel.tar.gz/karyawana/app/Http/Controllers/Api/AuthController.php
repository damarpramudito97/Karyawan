<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Login untuk mobile app (employee) maupun web admin.
     * Mendukung multi-tenant: company ditentukan dari akun user, bukan input manual.
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
            'fcm_token' => ['nullable', 'string'],
        ]);

        $user = User::with('company', 'employee')
            ->where('email', $request->email)
            ->first();

        if (! $user || ! Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => 'Email atau password salah.',
            ]);
        }

        if (! $user->is_active) {
            throw ValidationException::withMessages([
                'email' => 'Akun Anda tidak aktif. Silakan hubungi admin perusahaan.',
            ]);
        }

        if ($user->company && ! $user->company->is_active) {
            throw ValidationException::withMessages([
                'email' => 'Perusahaan Anda saat ini tidak aktif. Silakan hubungi administrator.',
            ]);
        }

        if ($request->filled('fcm_token')) {
            $user->update(['fcm_token' => $request->fcm_token]);
        }

        $token = $user->createToken('mobile')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
                'company' => $user->company ? [
                    'id' => $user->company->id,
                    'name' => $user->company->name,
                    'subscription_status' => $user->company->subscription_status,
                ] : null,
                'employee' => $user->employee ? [
                    'id' => $user->employee->id,
                    'employee_code' => $user->employee->employee_code,
                    'name' => $user->employee->name,
                    'position' => $user->employee->position,
                    'photo_url' => $user->employee->photo ? asset('storage/' . $user->employee->photo) : null,
                ] : null,
            ],
        ]);
    }

    public function me(Request $request)
    {
        return response()->json(['user' => $request->user()->load('company', 'employee')]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'Logout berhasil.']);
    }
}

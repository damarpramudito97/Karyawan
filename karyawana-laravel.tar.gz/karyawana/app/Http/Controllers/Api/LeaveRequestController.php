<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\LeaveRequest\StoreLeaveRequestRequest;
use App\Http\Resources\LeaveRequestResource;
use App\Models\LeaveRequest;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class LeaveRequestController extends Controller
{
    /**
     * Daftar pengajuan milik karyawan yang login, bisa difilter berdasarkan status.
     */
    public function index(Request $request)
    {
        $employee = $request->user()->employee;

        $query = LeaveRequest::where('employee_id', $employee->id)
            ->orderByDesc('created_at');

        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        if ($request->filled('type')) {
            $query->where('type', $request->input('type'));
        }

        return LeaveRequestResource::collection($query->paginate(20));
    }

    public function show(Request $request, LeaveRequest $leaveRequest)
    {
        $this->authorizeOwnership($request, $leaveRequest);

        return new LeaveRequestResource($leaveRequest);
    }

    public function store(StoreLeaveRequestRequest $request)
    {
        $employee = $request->user()->employee;

        $data = $request->validated();
        $data['employee_id'] = $employee->id;
        $data['company_id'] = $employee->company_id;
        $data['status'] = 'pending';

        if ($request->hasFile('attachment')) {
            $data['attachment'] = $request->file('attachment')->store(
                "leave-attachments/{$employee->company_id}/{$employee->id}",
                'public'
            );
        }

        $leaveRequest = LeaveRequest::create($data);

        return response()->json([
            'message' => 'Pengajuan berhasil dikirim dan menunggu persetujuan.',
            'data' => new LeaveRequestResource($leaveRequest),
        ], 201);
    }

    /**
     * Karyawan membatalkan pengajuan yang masih pending.
     */
    public function cancel(Request $request, LeaveRequest $leaveRequest)
    {
        $this->authorizeOwnership($request, $leaveRequest);

        if ($leaveRequest->status !== 'pending') {
            throw ValidationException::withMessages([
                'status' => 'Hanya pengajuan dengan status pending yang dapat dibatalkan.',
            ]);
        }

        $leaveRequest->update(['status' => 'cancelled']);

        return response()->json([
            'message' => 'Pengajuan berhasil dibatalkan.',
            'data' => new LeaveRequestResource($leaveRequest),
        ]);
    }

    protected function authorizeOwnership(Request $request, LeaveRequest $leaveRequest): void
    {
        $employee = $request->user()->employee;

        abort_if(
            ! $employee || $leaveRequest->employee_id !== $employee->id,
            403,
            'Anda tidak memiliki akses ke pengajuan ini.'
        );
    }
}

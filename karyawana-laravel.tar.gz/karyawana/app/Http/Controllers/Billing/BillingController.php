<?php

namespace App\Http\Controllers\Billing;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionPlan;
use App\Services\MidtransService;
use Illuminate\Http\Request;

class BillingController extends Controller
{
    public function __construct(protected MidtransService $midtrans)
    {
    }

    /**
     * Dipanggil dari Filament Page "Billing" saat admin perusahaan klik "Upgrade/Bayar".
     */
    public function checkout(Request $request, SubscriptionPlan $plan)
    {
        $company = $request->user()->company;

        $result = $this->midtrans->createTransaction($company, $plan);

        return response()->json($result);
    }

    /**
     * Endpoint webhook Midtrans. Daftarkan URL ini di Midtrans Dashboard:
     * Settings > Configuration > Payment Notification URL
     *
     * Route ini HARUS bebas dari middleware auth & CSRF (lihat routes/billing.php).
     */
    public function webhook(Request $request)
    {
        $this->midtrans->handleNotification($request->all());

        return response()->json(['status' => 'ok']);
    }
}

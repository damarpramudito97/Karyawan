<?php

namespace App\Filament\Pages;

use App\Models\Payment;
use App\Models\SubscriptionPlan;
use Filament\Pages\Page;

class Billing extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-credit-card';

    protected static ?string $navigationLabel = 'Subscription & Billing';

    protected static ?string $navigationGroup = 'Pengaturan Presensi';

    protected static ?int $navigationSort = 99;

    protected static string $view = 'filament.pages.billing';

    public function getCompany()
    {
        return auth()->user()->company;
    }

    public function getPlans()
    {
        return SubscriptionPlan::where('is_active', true)->orderBy('price')->get();
    }

    public function getPaymentHistory()
    {
        return Payment::where('company_id', auth()->user()->company_id)
            ->latest()
            ->limit(10)
            ->get();
    }
}

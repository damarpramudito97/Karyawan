<?php

namespace App\Filament\Pages;

use App\Models\Setting;
use Filament\Forms;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Pages\Page;

class CompanySettings extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon = 'heroicon-o-cog-6-tooth';

    protected static ?string $navigationLabel = 'Pengaturan Presensi';

    protected static ?string $navigationGroup = 'Pengaturan Presensi';

    protected static string $view = 'filament.pages.company-settings';

    public ?array $data = [];

    public function mount(): void
    {
        $companyId = auth()->user()->company_id;

        $this->form->fill([
            'require_selfie' => (bool) Setting::getValue($companyId, 'require_selfie', true),
            'reject_mock_location' => (bool) Setting::getValue($companyId, 'reject_mock_location', true),
            'reject_outside_radius' => (bool) Setting::getValue($companyId, 'reject_outside_radius', true),
            'max_gps_accuracy_meters' => (int) Setting::getValue($companyId, 'max_gps_accuracy_meters', 50),
        ]);
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Validasi Presensi')
                ->description('Aturan ini berlaku untuk seluruh karyawan saat check-in & check-out via mobile app.')
                ->schema([
                    Forms\Components\Toggle::make('require_selfie')
                        ->label('Wajib Selfie')
                        ->helperText('Karyawan wajib mengambil foto selfie setiap check-in/check-out.')
                        ->inline(false),

                    Forms\Components\Toggle::make('reject_mock_location')
                        ->label('Tolak Fake GPS / Mock Location')
                        ->helperText('Presensi otomatis ditolak jika sistem mendeteksi penggunaan lokasi palsu.')
                        ->inline(false),

                    Forms\Components\Toggle::make('reject_outside_radius')
                        ->label('Tolak Presensi di Luar Radius')
                        ->helperText('Presensi otomatis ditolak jika karyawan berada di luar radius geofence lokasi.')
                        ->inline(false),

                    Forms\Components\TextInput::make('max_gps_accuracy_meters')
                        ->label('Akurasi GPS Maksimum')
                        ->numeric()
                        ->required()
                        ->minValue(5)
                        ->suffix('meter')
                        ->helperText('Presensi ditolak jika akurasi GPS perangkat lebih buruk dari nilai ini.'),
                ])
                ->columns(2),
        ])->statePath('data');
    }

    public function save(): void
    {
        $data = $this->form->getState();
        $companyId = auth()->user()->company_id;

        foreach ($data as $key => $value) {
            Setting::setValue($companyId, $key, is_bool($value) ? (int) $value : $value);
        }

        Notification::make()
            ->title('Pengaturan berhasil disimpan')
            ->success()
            ->send();
    }
}

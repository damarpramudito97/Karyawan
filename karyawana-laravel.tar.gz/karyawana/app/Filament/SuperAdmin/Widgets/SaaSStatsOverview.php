<?php

namespace App\Filament\SuperAdmin\Widgets;

use App\Models\Company;
use App\Models\Payment;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class SaaSStatsOverview extends BaseWidget
{
    protected function getStats(): array
    {
        $totalCompanies = Company::count();
        $activeCompanies = Company::where('subscription_status', 'active')->count();
        $trialCompanies = Company::where('subscription_status', 'trial')->count();

        $thisMonthRevenue = Payment::where('status', 'paid')
            ->whereMonth('paid_at', now()->month)
            ->whereYear('paid_at', now()->year)
            ->sum('amount');

        $lastMonthRevenue = Payment::where('status', 'paid')
            ->whereMonth('paid_at', now()->subMonth()->month)
            ->whereYear('paid_at', now()->subMonth()->year)
            ->sum('amount');

        $growth = $lastMonthRevenue > 0
            ? round((($thisMonthRevenue - $lastMonthRevenue) / $lastMonthRevenue) * 100, 1)
            : null;

        return [
            Stat::make('Total Tenant', (string) $totalCompanies)
                ->description("{$activeCompanies} aktif, {$trialCompanies} trial")
                ->color('success'),

            Stat::make('Revenue Bulan Ini', 'Rp ' . number_format($thisMonthRevenue, 0, ',', '.'))
                ->description($growth !== null
                    ? ($growth >= 0 ? "+{$growth}% dari bulan lalu" : "{$growth}% dari bulan lalu")
                    : 'Belum ada data bulan lalu')
                ->color($growth !== null && $growth < 0 ? 'danger' : 'success'),

            Stat::make('Tenant Trial', (string) $trialCompanies)
                ->description('belum berlangganan paket berbayar')
                ->color('warning'),
        ];
    }
}

<?php

namespace App\Filament\SuperAdmin\Resources;

use App\Filament\SuperAdmin\Resources\SubscriptionPlanResource\Pages;
use App\Models\SubscriptionPlan;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class SubscriptionPlanResource extends Resource
{
    protected static ?string $model = SubscriptionPlan::class;

    protected static ?string $navigationIcon = 'heroicon-o-tag';

    protected static ?string $navigationLabel = 'Paket Subscription';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')->label('Nama Paket')->required(),
            Forms\Components\TextInput::make('slug')->label('Slug')->required()->unique(ignoreRecord: true),
            Forms\Components\Textarea::make('description')->label('Deskripsi')->columnSpanFull(),

            Forms\Components\TextInput::make('price')
                ->label('Harga')
                ->numeric()
                ->required()
                ->prefix('Rp'),

            Forms\Components\Select::make('billing_cycle')
                ->label('Siklus Tagihan')
                ->options(['monthly' => 'Bulanan', 'yearly' => 'Tahunan'])
                ->required(),

            Forms\Components\TextInput::make('max_employees')
                ->label('Maks. Karyawan')
                ->numeric()
                ->helperText('Kosongkan untuk unlimited'),

            Forms\Components\TextInput::make('max_locations')
                ->label('Maks. Lokasi/Cabang')
                ->numeric()
                ->helperText('Kosongkan untuk unlimited'),

            Forms\Components\TagsInput::make('features')
                ->label('Fitur')
                ->placeholder('Tambahkan fitur lalu tekan Enter')
                ->columnSpanFull(),

            Forms\Components\Toggle::make('is_active')->label('Aktif')->default(true),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Nama Paket')->searchable(),
                Tables\Columns\TextColumn::make('price')->label('Harga')->money('IDR'),
                Tables\Columns\TextColumn::make('billing_cycle')->label('Siklus')
                    ->formatStateUsing(fn (string $state) => $state === 'yearly' ? 'Tahunan' : 'Bulanan'),
                Tables\Columns\TextColumn::make('max_employees')->label('Maks. Karyawan')->placeholder('Unlimited'),
                Tables\Columns\TextColumn::make('companies_count')->label('Jumlah Tenant')->counts('companies'),
                Tables\Columns\IconColumn::make('is_active')->label('Aktif')->boolean(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSubscriptionPlans::route('/'),
            'create' => Pages\CreateSubscriptionPlan::route('/create'),
            'edit' => Pages\EditSubscriptionPlan::route('/{record}/edit'),
        ];
    }
}

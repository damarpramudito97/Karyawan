<?php

namespace App\Filament\SuperAdmin\Resources\PaymentResource\Pages;

use App\Filament\SuperAdmin\Resources\PaymentResource;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Filament\Resources\Pages\ViewRecord;

class ViewPayment extends ViewRecord
{
    protected static string $resource = PaymentResource::class;

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist->schema([
            Infolists\Components\Section::make('Detail Transaksi')
                ->schema([
                    Infolists\Components\TextEntry::make('invoice_number')->label('No. Invoice'),
                    Infolists\Components\TextEntry::make('company.name')->label('Perusahaan'),
                    Infolists\Components\TextEntry::make('amount')->label('Jumlah')->money('IDR'),
                    Infolists\Components\TextEntry::make('payment_gateway')->label('Gateway'),
                    Infolists\Components\TextEntry::make('payment_method')->label('Metode Pembayaran'),
                    Infolists\Components\TextEntry::make('transaction_id')->label('ID Transaksi'),
                    Infolists\Components\TextEntry::make('status')->label('Status')->badge(),
                    Infolists\Components\TextEntry::make('paid_at')->label('Tanggal Bayar')->dateTime('d M Y H:i'),
                ])->columns(2),

            Infolists\Components\Section::make('Response Gateway (Raw)')
                ->schema([
                    Infolists\Components\TextEntry::make('gateway_response')
                        ->label('')
                        ->formatStateUsing(fn ($state) => json_encode($state, JSON_PRETTY_PRINT))
                        ->columnSpanFull(),
                ])
                ->collapsed(),
        ]);
    }
}

<?php

namespace App\Filament\SuperAdmin\Resources;

use App\Filament\SuperAdmin\Resources\CompanyResource\Pages;
use App\Models\Company;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class CompanyResource extends Resource
{
    protected static ?string $model = Company::class;

    protected static ?string $navigationIcon = 'heroicon-o-building-office';

    protected static ?string $navigationLabel = 'Perusahaan (Tenant)';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')
                ->label('Nama Perusahaan')
                ->required()
                ->maxLength(255),

            Forms\Components\TextInput::make('slug')
                ->label('Slug')
                ->required()
                ->unique(ignoreRecord: true)
                ->maxLength(255),

            Forms\Components\TextInput::make('email')->label('Email')->email(),
            Forms\Components\TextInput::make('phone')->label('No. Telepon'),

            Forms\Components\Textarea::make('address')->label('Alamat')->columnSpanFull(),

            Forms\Components\Select::make('subscription_plan_id')
                ->label('Paket Subscription')
                ->relationship('subscriptionPlan', 'name'),

            Forms\Components\Select::make('subscription_status')
                ->label('Status Subscription')
                ->options([
                    'trial' => 'Trial',
                    'active' => 'Aktif',
                    'expired' => 'Expired',
                    'suspended' => 'Suspended',
                ])
                ->required(),

            Forms\Components\DatePicker::make('trial_ends_at')->label('Trial Berakhir'),
            Forms\Components\DatePicker::make('subscription_ends_at')->label('Subscription Berakhir'),

            Forms\Components\Toggle::make('is_active')
                ->label('Aktif')
                ->default(true)
                ->helperText('Jika dinonaktifkan, seluruh user perusahaan ini tidak dapat login.')
                ->columnSpanFull(),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Nama Perusahaan')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('subscriptionPlan.name')->label('Paket')->badge(),
                Tables\Columns\BadgeColumn::make('subscription_status')
                    ->label('Status')
                    ->colors([
                        'gray' => 'trial',
                        'success' => 'active',
                        'warning' => 'expired',
                        'danger' => 'suspended',
                    ]),
                Tables\Columns\TextColumn::make('employees_count')
                    ->label('Karyawan')
                    ->counts('employees'),
                Tables\Columns\TextColumn::make('subscription_ends_at')->label('Berlaku Sampai')->date('d M Y'),
                Tables\Columns\IconColumn::make('is_active')->label('Aktif')->boolean(),
                Tables\Columns\TextColumn::make('created_at')->label('Terdaftar')->date('d M Y'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('subscription_status')
                    ->label('Status')
                    ->options([
                        'trial' => 'Trial', 'active' => 'Aktif',
                        'expired' => 'Expired', 'suspended' => 'Suspended',
                    ]),
            ])
            ->actions([
                Tables\Actions\Action::make('suspend')
                    ->label('Suspend')
                    ->icon('heroicon-o-lock-closed')
                    ->color('danger')
                    ->visible(fn (Company $record) => $record->is_active)
                    ->requiresConfirmation()
                    ->action(function (Company $record) {
                        $record->update(['is_active' => false, 'subscription_status' => 'suspended']);
                        Notification::make()->title('Perusahaan disuspend')->warning()->send();
                    }),

                Tables\Actions\Action::make('activate')
                    ->label('Aktifkan')
                    ->icon('heroicon-o-lock-open')
                    ->color('success')
                    ->visible(fn (Company $record) => ! $record->is_active)
                    ->action(function (Company $record) {
                        $record->update(['is_active' => true]);
                        Notification::make()->title('Perusahaan diaktifkan kembali')->success()->send();
                    }),

                Tables\Actions\EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCompanies::route('/'),
            'create' => Pages\CreateCompany::route('/create'),
            'edit' => Pages\EditCompany::route('/{record}/edit'),
        ];
    }
}

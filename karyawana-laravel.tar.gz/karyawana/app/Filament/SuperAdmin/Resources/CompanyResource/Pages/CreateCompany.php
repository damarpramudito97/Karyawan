<?php

namespace App\Filament\SuperAdmin\Resources\CompanyResource\Pages;

use App\Filament\SuperAdmin\Resources\CompanyResource;
use Database\Seeders\DefaultSettingsSeeder as SettingsSeeder;
use Filament\Resources\Pages\CreateRecord;

class CreateCompany extends CreateRecord
{
    protected static string $resource = CompanyResource::class;

    protected function afterCreate(): void
    {
        // Buat default settings (require_selfie, reject_mock_location, dll) untuk tenant baru
        SettingsSeeder::seedForCompany($this->record->id);
    }
}

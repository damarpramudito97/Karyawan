<?php

namespace App\Filament\Widgets;

use App\Models\LeaveRequest;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class PendingLeaveRequests extends BaseWidget
{
    protected static ?string $heading = 'Pengajuan menunggu';

    protected int|string|array $columnSpan = 1;

    public function table(Table $table): Table
    {
        return $table
            ->query(
                LeaveRequest::query()
                    ->where('status', 'pending')
                    ->latest()
                    ->limit(5)
            )
            ->columns([
                Tables\Columns\TextColumn::make('employee.name')->label('Karyawan'),
                Tables\Columns\BadgeColumn::make('type')
                    ->label('Jenis')
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'cuti' => 'Cuti', 'izin' => 'Izin', 'sakit' => 'Sakit',
                        'lembur' => 'Lembur', 'wfh' => 'WFH', 'wfa' => 'WFA',
                        default => $state,
                    }),
                Tables\Columns\TextColumn::make('start_date')->label('Mulai')->date('d M'),
            ])
            ->paginated(false);
    }
}

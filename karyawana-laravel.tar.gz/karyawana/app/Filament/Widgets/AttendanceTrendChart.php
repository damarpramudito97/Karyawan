<?php

namespace App\Filament\Widgets;

use App\Models\Attendance;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Carbon;

class AttendanceTrendChart extends ChartWidget
{
    protected static ?string $heading = 'Tren kehadiran 7 hari terakhir';

    protected int|string|array $columnSpan = 2;

    protected function getData(): array
    {
        $days = collect(range(6, 0))->map(fn ($i) => Carbon::today()->subDays($i));

        $counts = $days->map(function (Carbon $day) {
            return Attendance::whereDate('date', $day)
                ->whereIn('status', ['present', 'late', 'wfh', 'wfa'])
                ->count();
        });

        return [
            'datasets' => [
                [
                    'label' => 'Karyawan hadir',
                    'data' => $counts->toArray(),
                    'backgroundColor' => '#1D9E75',
                ],
            ],
            'labels' => $days->map(fn (Carbon $day) => $day->translatedFormat('D'))->toArray(),
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }
}

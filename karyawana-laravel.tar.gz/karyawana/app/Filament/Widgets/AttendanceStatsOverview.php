<?php

namespace App\Filament\Widgets;

use App\Models\Attendance;
use App\Models\Employee;
use App\Models\LeaveRequest;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class AttendanceStatsOverview extends BaseWidget
{
    protected function getStats(): array
    {
        $today = now()->toDateString();

        $totalEmployees = Employee::where('status', 'active')->count();

        $present = Attendance::whereDate('date', $today)
            ->whereIn('status', ['present', 'late', 'wfh', 'wfa'])
            ->count();

        $late = Attendance::whereDate('date', $today)
            ->where('status', 'late')
            ->count();

        $onLeave = Attendance::whereDate('date', $today)
            ->whereIn('status', ['leave', 'sick', 'permission'])
            ->count();

        $pendingLeave = LeaveRequest::where('status', 'pending')->count();

        $absent = max($totalEmployees - $present - $onLeave, 0);

        return [
            Stat::make('Hadir hari ini', "{$present} / {$totalEmployees}")
                ->description('dari total karyawan aktif')
                ->color('success'),

            Stat::make('Terlambat', (string) $late)
                ->description('karyawan terlambat hari ini')
                ->color('warning'),

            Stat::make('Izin / Sakit', (string) $onLeave)
                ->description("{$pendingLeave} pengajuan menunggu approval")
                ->color('gray'),

            Stat::make('Tidak hadir', (string) $absent)
                ->description('tanpa keterangan')
                ->color('danger'),
        ];
    }
}

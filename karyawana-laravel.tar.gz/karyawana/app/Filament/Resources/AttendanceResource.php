<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AttendanceResource\Pages;
use App\Models\Attendance;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class AttendanceResource extends Resource
{
    protected static ?string $model = Attendance::class;

    protected static ?string $navigationIcon = 'heroicon-o-finger-print';

    protected static ?string $navigationGroup = 'Laporan';

    protected static ?string $navigationLabel = 'Presensi';

    public static function canCreate(): bool
    {
        return false; // data presensi hanya dari mobile app
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('date', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('date')->label('Tanggal')->date('d M Y')->sortable(),
                Tables\Columns\TextColumn::make('employee.name')->label('Karyawan')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('shift.name')->label('Shift'),
                Tables\Columns\TextColumn::make('location.name')->label('Lokasi'),
                Tables\Columns\TextColumn::make('check_in_at')->label('Check-in')->dateTime('H:i:s'),
                Tables\Columns\TextColumn::make('check_out_at')->label('Check-out')->dateTime('H:i:s'),
                Tables\Columns\TextColumn::make('late_minutes')->label('Telat (mnt)')->sortable(),
                Tables\Columns\TextColumn::make('early_leave_minutes')->label('Pulang Awal (mnt)'),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Status')
                    ->colors([
                        'success' => 'present',
                        'warning' => fn ($state) => in_array($state, ['late', 'wfh', 'wfa']),
                        'danger' => 'absent',
                        'gray' => fn ($state) => in_array($state, ['leave', 'sick', 'permission', 'day_off']),
                    ])
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'present' => 'Hadir',
                        'late' => 'Terlambat',
                        'absent' => 'Tidak Hadir',
                        'leave' => 'Cuti',
                        'sick' => 'Sakit',
                        'permission' => 'Izin',
                        'wfh' => 'WFH',
                        'wfa' => 'WFA',
                        'day_off' => 'Libur',
                        default => $state,
                    }),
                Tables\Columns\IconColumn::make('check_in_is_mock_location')
                    ->label('Fake GPS')
                    ->boolean()
                    ->trueIcon('heroicon-o-exclamation-triangle')
                    ->falseIcon('heroicon-o-check-circle')
                    ->trueColor('danger')
                    ->falseColor('success'),
            ])
            ->filters([
                Tables\Filters\Filter::make('date')
                    ->form([
                        Forms\Components\DatePicker::make('from')->label('Dari Tanggal'),
                        Forms\Components\DatePicker::make('until')->label('Sampai Tanggal'),
                    ])
                    ->query(function ($query, array $data) {
                        return $query
                            ->when($data['from'], fn ($q) => $q->whereDate('date', '>=', $data['from']))
                            ->when($data['until'], fn ($q) => $q->whereDate('date', '<=', $data['until']));
                    }),
                Tables\Filters\SelectFilter::make('employee_id')
                    ->label('Karyawan')
                    ->relationship('employee', 'name')
                    ->searchable(),
                Tables\Filters\SelectFilter::make('status')
                    ->label('Status')
                    ->options([
                        'present' => 'Hadir',
                        'late' => 'Terlambat',
                        'absent' => 'Tidak Hadir',
                        'leave' => 'Cuti',
                        'sick' => 'Sakit',
                        'permission' => 'Izin',
                        'wfh' => 'WFH',
                        'wfa' => 'WFA',
                    ]),
            ])
            ->headerActions([
                Tables\Actions\Action::make('export_pdf')
                    ->label('Export PDF')
                    ->icon('heroicon-o-document-text')
                    ->color('gray')
                    ->url(fn (Tables\Contracts\HasTable $livewire) => route('reports.attendance.pdf', request()->query()))
                    ->openUrlInNewTab(),

                Tables\Actions\Action::make('export_excel')
                    ->label('Export Excel')
                    ->icon('heroicon-o-table-cells')
                    ->color('gray')
                    ->url(fn () => route('reports.attendance.excel', request()->query()))
                    ->openUrlInNewTab(),

                Tables\Actions\Action::make('export_csv')
                    ->label('Export CSV')
                    ->icon('heroicon-o-document')
                    ->color('gray')
                    ->url(fn () => route('reports.attendance.csv', request()->query()))
                    ->openUrlInNewTab(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAttendances::route('/'),
        ];
    }
}

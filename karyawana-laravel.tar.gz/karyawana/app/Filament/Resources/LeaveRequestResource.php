<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LeaveRequestResource\Pages;
use App\Models\LeaveRequest;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class LeaveRequestResource extends Resource
{
    protected static ?string $model = LeaveRequest::class;

    protected static ?string $navigationIcon = 'heroicon-o-calendar-days';

    protected static ?string $navigationGroup = 'Pengajuan';

    protected static ?string $navigationLabel = 'Cuti, Izin & Lembur';

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::where('status', 'pending')->count() ?: null;
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('employee_id')
                ->label('Karyawan')
                ->relationship('employee', 'name')
                ->searchable()
                ->preload()
                ->required(),

            Forms\Components\Select::make('type')
                ->label('Jenis Pengajuan')
                ->options([
                    'cuti' => 'Cuti',
                    'izin' => 'Izin',
                    'sakit' => 'Sakit',
                    'lembur' => 'Lembur',
                    'wfh' => 'WFH',
                    'wfa' => 'WFA',
                ])
                ->required(),

            Forms\Components\DatePicker::make('start_date')->label('Tanggal Mulai')->required(),
            Forms\Components\DatePicker::make('end_date')->label('Tanggal Selesai')->required(),

            Forms\Components\TimePicker::make('start_time')->label('Jam Mulai (khusus lembur)')->seconds(false),
            Forms\Components\TimePicker::make('end_time')->label('Jam Selesai (khusus lembur)')->seconds(false),

            Forms\Components\Textarea::make('reason')
                ->label('Alasan')
                ->required()
                ->columnSpanFull(),

            Forms\Components\Select::make('status')
                ->label('Status')
                ->options([
                    'pending' => 'Menunggu',
                    'approved' => 'Disetujui',
                    'rejected' => 'Ditolak',
                    'cancelled' => 'Dibatalkan',
                ])
                ->required(),

            Forms\Components\Textarea::make('approval_notes')
                ->label('Catatan Approval')
                ->columnSpanFull(),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('employee.name')->label('Karyawan')->searchable()->sortable(),
                Tables\Columns\BadgeColumn::make('type')
                    ->label('Jenis')
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'cuti' => 'Cuti',
                        'izin' => 'Izin',
                        'sakit' => 'Sakit',
                        'lembur' => 'Lembur',
                        'wfh' => 'WFH',
                        'wfa' => 'WFA',
                        default => $state,
                    }),
                Tables\Columns\TextColumn::make('start_date')->label('Mulai')->date('d M Y'),
                Tables\Columns\TextColumn::make('end_date')->label('Selesai')->date('d M Y'),
                Tables\Columns\TextColumn::make('reason')->label('Alasan')->limit(40)->wrap(),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Status')
                    ->colors([
                        'warning' => 'pending',
                        'success' => 'approved',
                        'danger' => 'rejected',
                        'gray' => 'cancelled',
                    ])
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'pending' => 'Menunggu',
                        'approved' => 'Disetujui',
                        'rejected' => 'Ditolak',
                        'cancelled' => 'Dibatalkan',
                        default => $state,
                    }),
                Tables\Columns\TextColumn::make('created_at')->label('Diajukan')->dateTime('d M Y H:i'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Status')
                    ->options([
                        'pending' => 'Menunggu',
                        'approved' => 'Disetujui',
                        'rejected' => 'Ditolak',
                        'cancelled' => 'Dibatalkan',
                    ])
                    ->default('pending'),
                Tables\Filters\SelectFilter::make('type')
                    ->label('Jenis')
                    ->options([
                        'cuti' => 'Cuti', 'izin' => 'Izin', 'sakit' => 'Sakit',
                        'lembur' => 'Lembur', 'wfh' => 'WFH', 'wfa' => 'WFA',
                    ]),
            ])
            ->actions([
                Tables\Actions\Action::make('approve')
                    ->label('Setujui')
                    ->icon('heroicon-o-check')
                    ->color('success')
                    ->visible(fn (LeaveRequest $record) => $record->status === 'pending')
                    ->requiresConfirmation()
                    ->form([
                        Forms\Components\Textarea::make('notes')->label('Catatan (opsional)'),
                    ])
                    ->action(function (LeaveRequest $record, array $data) {
                        $record->approve(auth()->user(), $data['notes'] ?? null);

                        Notification::make()
                            ->title('Pengajuan disetujui')
                            ->success()
                            ->send();
                    }),

                Tables\Actions\Action::make('reject')
                    ->label('Tolak')
                    ->icon('heroicon-o-x-mark')
                    ->color('danger')
                    ->visible(fn (LeaveRequest $record) => $record->status === 'pending')
                    ->requiresConfirmation()
                    ->form([
                        Forms\Components\Textarea::make('notes')->label('Alasan Penolakan')->required(),
                    ])
                    ->action(function (LeaveRequest $record, array $data) {
                        $record->reject(auth()->user(), $data['notes']);

                        Notification::make()
                            ->title('Pengajuan ditolak')
                            ->warning()
                            ->send();
                    }),

                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLeaveRequests::route('/'),
            'edit' => Pages\EditLeaveRequest::route('/{record}/edit'),
        ];
    }
}

<?php

namespace App\Filament\Resources\EmployeeResource\Pages;

use App\Filament\Resources\EmployeeResource;
use App\Models\Employee;
use Filament\Resources\Pages\CreateRecord;

class CreateEmployee extends CreateRecord
{
    protected static string $resource = EmployeeResource::class;

    protected function afterCreate(): void
    {
        /** @var Employee $employee */
        $employee = $this->record;

        EmployeeResource::syncUserAccount(
            $employee,
            $this->data['account_password'] ?? null
        );
    }
}

<?php

namespace App\Filament\Resources;

use App\Filament\Resources\WorkScheduleResource\Pages;
use App\Models\WorkSchedule;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class WorkScheduleResource extends Resource
{
    protected static ?string $model = WorkSchedule::class;

    protected static ?string $navigationIcon = 'heroicon-o-calendar-days';

    protected static ?string $navigationGroup = 'Pengaturan Presensi';

    protected static ?string $navigationLabel = 'Jadwal Kerja';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('employee_id')
                ->label('Karyawan')
                ->relationship('employee', 'name')
                ->searchable()
                ->preload()
                ->required(),

            Forms\Components\DatePicker::make('date')
                ->label('Tanggal')
                ->required(),

            Forms\Components\Toggle::make('is_day_off')
                ->label('Hari Libur')
                ->live()
                ->columnSpanFull(),

            Forms\Components\Select::make('shift_id')
                ->label('Shift')
                ->relationship('shift', 'name')
                ->searchable()
                ->preload()
                ->required(fn (Forms\Get $get) => ! $get('is_day_off'))
                ->visible(fn (Forms\Get $get) => ! $get('is_day_off')),

            Forms\Components\Select::make('location_id')
                ->label('Lokasi')
                ->relationship('location', 'name')
                ->searchable()
                ->preload()
                ->visible(fn (Forms\Get $get) => ! $get('is_day_off')),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('employee.name')->label('Karyawan')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('date')->label('Tanggal')->date('d M Y')->sortable(),
                Tables\Columns\TextColumn::make('shift.name')->label('Shift')
                    ->placeholder('Libur'),
                Tables\Columns\TextColumn::make('location.name')->label('Lokasi'),
                Tables\Columns\IconColumn::make('is_day_off')->label('Libur')->boolean(),
            ])
            ->filters([
                Tables\Filters\Filter::make('date')
                    ->form([
                        Forms\Components\DatePicker::make('from')->label('Dari'),
                        Forms\Components\DatePicker::make('until')->label('Sampai'),
                    ])
                    ->query(function ($query, array $data) {
                        return $query
                            ->when($data['from'], fn ($q) => $q->whereDate('date', '>=', $data['from']))
                            ->when($data['until'], fn ($q) => $q->whereDate('date', '<=', $data['until']));
                    }),
                Tables\Filters\SelectFilter::make('employee_id')
                    ->label('Karyawan')
                    ->relationship('employee', 'name')
                    ->searchable(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->headerActions([
                Tables\Actions\Action::make('generate_weekly')
                    ->label('Generate Jadwal Mingguan')
                    ->icon('heroicon-o-calendar')
                    ->color('gray')
                    ->form([
                        Forms\Components\Select::make('employee_ids')
                            ->label('Karyawan')
                            ->multiple()
                            ->relationship('employee', 'name')
                            ->options(fn () => \App\Models\Employee::pluck('name', 'id'))
                            ->required(),
                        Forms\Components\Select::make('shift_id')
                            ->label('Shift')
                            ->relationship('shift', 'name')
                            ->options(fn () => \App\Models\Shift::pluck('name', 'id'))
                            ->required(),
                        Forms\Components\Select::make('location_id')
                            ->label('Lokasi')
                            ->options(fn () => \App\Models\Location::pluck('name', 'id')),
                        Forms\Components\DatePicker::make('start_date')
                            ->label('Mulai Tanggal')
                            ->required(),
                        Forms\Components\CheckboxList::make('days')
                            ->label('Hari Kerja')
                            ->options([
                                1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis',
                                5 => 'Jumat', 6 => 'Sabtu', 0 => 'Minggu',
                            ])
                            ->default([1, 2, 3, 4, 5])
                            ->columns(4)
                            ->required(),
                    ])
                    ->action(function (array $data) {
                        $start = \Carbon\Carbon::parse($data['start_date'])->startOfWeek(\Carbon\Carbon::SUNDAY);

                        foreach ($data['employee_ids'] as $employeeId) {
                            for ($i = 0; $i < 7; $i++) {
                                $date = $start->copy()->addDays($i);

                                if (! in_array($date->dayOfWeek, $data['days'])) {
                                    continue;
                                }

                                WorkSchedule::updateOrCreate(
                                    ['employee_id' => $employeeId, 'date' => $date->toDateString()],
                                    [
                                        'shift_id' => $data['shift_id'],
                                        'location_id' => $data['location_id'] ?? null,
                                        'is_day_off' => false,
                                    ]
                                );
                            }
                        }
                    })
                    ->successNotificationTitle('Jadwal mingguan berhasil dibuat.'),

                Tables\Actions\CreateAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListWorkSchedules::route('/'),
            'create' => Pages\CreateWorkSchedule::route('/create'),
            'edit' => Pages\EditWorkSchedule::route('/{record}/edit'),
        ];
    }
}

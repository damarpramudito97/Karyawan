<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ShiftResource\Pages;
use App\Models\Shift;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ShiftResource extends Resource
{
    protected static ?string $model = Shift::class;

    protected static ?string $navigationIcon = 'heroicon-o-clock';

    protected static ?string $navigationGroup = 'Pengaturan Presensi';

    protected static ?string $navigationLabel = 'Shift Kerja';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')
                ->label('Nama Shift')
                ->placeholder('Contoh: Shift Pagi, Shift Malam')
                ->required()
                ->maxLength(255)
                ->columnSpanFull(),

            Forms\Components\TimePicker::make('start_time')
                ->label('Jam Masuk')
                ->seconds(false)
                ->required(),

            Forms\Components\TimePicker::make('end_time')
                ->label('Jam Keluar')
                ->seconds(false)
                ->required(),

            Forms\Components\Toggle::make('is_overnight')
                ->label('Shift Melewati Tengah Malam')
                ->helperText('Aktifkan jika jam keluar di hari berikutnya, contoh shift malam 22:00 - 06:00.')
                ->columnSpanFull(),

            Forms\Components\TextInput::make('late_tolerance_minutes')
                ->label('Toleransi Terlambat (menit)')
                ->numeric()
                ->default(0)
                ->suffix('menit'),

            Forms\Components\TextInput::make('early_leave_tolerance_minutes')
                ->label('Toleransi Pulang Awal (menit)')
                ->numeric()
                ->default(0)
                ->suffix('menit'),

            Forms\Components\Toggle::make('is_active')
                ->label('Aktif')
                ->default(true)
                ->columnSpanFull(),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Nama Shift')->searchable(),
                Tables\Columns\TextColumn::make('start_time')->label('Jam Masuk')->time('H:i'),
                Tables\Columns\TextColumn::make('end_time')->label('Jam Keluar')->time('H:i'),
                Tables\Columns\IconColumn::make('is_overnight')->label('Lintas Hari')->boolean(),
                Tables\Columns\TextColumn::make('late_tolerance_minutes')->label('Toleransi Telat')->suffix(' mnt'),
                Tables\Columns\TextColumn::make('early_leave_tolerance_minutes')->label('Toleransi Pulang Awal')->suffix(' mnt'),
                Tables\Columns\IconColumn::make('is_active')->label('Aktif')->boolean(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListShifts::route('/'),
            'create' => Pages\CreateShift::route('/create'),
            'edit' => Pages\EditShift::route('/{record}/edit'),
        ];
    }
}

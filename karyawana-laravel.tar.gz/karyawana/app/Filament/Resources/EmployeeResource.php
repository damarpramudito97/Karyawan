<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EmployeeResource\Pages;
use App\Models\Employee;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Hash;

class EmployeeResource extends Resource
{
    protected static ?string $model = Employee::class;

    protected static ?string $navigationIcon = 'heroicon-o-users';

    protected static ?string $navigationGroup = 'Manajemen Karyawan';

    protected static ?string $navigationLabel = 'Karyawan';

    protected static ?int $navigationSort = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Data Pribadi')
                ->schema([
                    Forms\Components\FileUpload::make('photo')
                        ->label('Foto')
                        ->image()
                        ->avatar()
                        ->directory('employee-photos')
                        ->columnSpanFull(),

                    Forms\Components\TextInput::make('employee_code')
                        ->label('Kode/NIP Karyawan')
                        ->maxLength(50),

                    Forms\Components\TextInput::make('name')
                        ->label('Nama Lengkap')
                        ->required()
                        ->maxLength(255),

                    Forms\Components\TextInput::make('email')
                        ->label('Email')
                        ->email()
                        ->maxLength(255)
                        ->helperText('Digunakan sebagai akun login mobile (opsional saat dibuat).'),

                    Forms\Components\TextInput::make('phone')
                        ->label('No. HP')
                        ->tel()
                        ->maxLength(20),

                    Forms\Components\Select::make('gender')
                        ->label('Jenis Kelamin')
                        ->options([
                            'male' => 'Laki-laki',
                            'female' => 'Perempuan',
                        ]),

                    Forms\Components\DatePicker::make('birth_date')
                        ->label('Tanggal Lahir'),

                    Forms\Components\Textarea::make('address')
                        ->label('Alamat')
                        ->columnSpanFull(),
                ])->columns(2),

            Forms\Components\Section::make('Penempatan & Kepegawaian')
                ->schema([
                    Forms\Components\Select::make('department_id')
                        ->label('Departemen')
                        ->relationship('department', 'name')
                        ->searchable()
                        ->preload(),

                    Forms\Components\Select::make('division_id')
                        ->label('Divisi')
                        ->relationship('division', 'name')
                        ->searchable()
                        ->preload(),

                    Forms\Components\Select::make('location_id')
                        ->label('Lokasi/Cabang Default')
                        ->relationship('location', 'name')
                        ->searchable()
                        ->preload()
                        ->helperText('Lokasi ini digunakan sebagai acuan geofence jika tidak ada jadwal khusus.'),

                    Forms\Components\TextInput::make('position')
                        ->label('Jabatan')
                        ->maxLength(255),

                    Forms\Components\DatePicker::make('join_date')
                        ->label('Tanggal Masuk'),

                    Forms\Components\Select::make('employment_status')
                        ->label('Status Kepegawaian')
                        ->options([
                            'permanent' => 'Tetap',
                            'contract' => 'Kontrak',
                            'probation' => 'Probation',
                            'intern' => 'Magang',
                        ])
                        ->default('permanent')
                        ->required(),

                    Forms\Components\Select::make('status')
                        ->label('Status Aktif')
                        ->options([
                            'active' => 'Aktif',
                            'inactive' => 'Non-aktif',
                            'resigned' => 'Resign',
                        ])
                        ->default('active')
                        ->required(),
                ])->columns(2),

            Forms\Components\Section::make('Akun Login Mobile')
                ->description('Buat akun agar karyawan bisa login ke aplikasi mobile.')
                ->schema([
                    Forms\Components\TextInput::make('account_password')
                        ->label('Password')
                        ->password()
                        ->revealable()
                        ->dehydrated(false)
                        ->helperText('Kosongkan jika tidak ingin mengubah password. Wajib diisi untuk karyawan baru dengan email.')
                        ->minLength(6),
                ])
                ->visible(fn (string $context) => $context === 'create' || true),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('photo')
                    ->label('')
                    ->circular()
                    ->defaultImageUrl(asset('images/avatar-placeholder.png')),
                Tables\Columns\TextColumn::make('employee_code')->label('Kode')->searchable(),
                Tables\Columns\TextColumn::make('name')->label('Nama')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('department.name')->label('Departemen')->sortable(),
                Tables\Columns\TextColumn::make('division.name')->label('Divisi')->sortable(),
                Tables\Columns\TextColumn::make('location.name')->label('Lokasi'),
                Tables\Columns\TextColumn::make('position')->label('Jabatan'),
                Tables\Columns\BadgeColumn::make('employment_status')
                    ->label('Status Kepegawaian')
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'permanent' => 'Tetap',
                        'contract' => 'Kontrak',
                        'probation' => 'Probation',
                        'intern' => 'Magang',
                        default => $state,
                    }),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Status')
                    ->colors([
                        'success' => 'active',
                        'gray' => 'inactive',
                        'danger' => 'resigned',
                    ])
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'active' => 'Aktif',
                        'inactive' => 'Non-aktif',
                        'resigned' => 'Resign',
                        default => $state,
                    }),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('department_id')
                    ->label('Departemen')
                    ->relationship('department', 'name'),
                Tables\Filters\SelectFilter::make('location_id')
                    ->label('Lokasi')
                    ->relationship('location', 'name'),
                Tables\Filters\SelectFilter::make('status')
                    ->label('Status')
                    ->options([
                        'active' => 'Aktif',
                        'inactive' => 'Non-aktif',
                        'resigned' => 'Resign',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->headerActions([
                Tables\Actions\Action::make('import')
                    ->label('Import Excel')
                    ->icon('heroicon-o-arrow-up-tray')
                    ->color('gray')
                    ->form([
                        Forms\Components\FileUpload::make('file')
                            ->label('File Excel (.xlsx)')
                            ->disk('local')
                            ->directory('imports/employees')
                            ->required(),
                    ])
                    ->action(function (array $data) {
                        \Maatwebsite\Excel\Facades\Excel::import(
                            new \App\Imports\EmployeesImport(),
                            storage_path('app/' . $data['file'])
                        );
                    }),
                Tables\Actions\Action::make('export')
                    ->label('Export Excel')
                    ->icon('heroicon-o-arrow-down-tray')
                    ->color('gray')
                    ->action(fn () => \Maatwebsite\Excel\Facades\Excel::download(
                        new \App\Exports\EmployeesExport(),
                        'karyawan-' . now()->format('Ymd_His') . '.xlsx'
                    )),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListEmployees::route('/'),
            'create' => Pages\CreateEmployee::route('/create'),
            'edit' => Pages\EditEmployee::route('/{record}/edit'),
        ];
    }

    /**
     * Buat/perbarui akun User terkait saat menyimpan data Employee
     * (dipanggil dari Pages\CreateEmployee & EditEmployee).
     */
    public static function syncUserAccount(Employee $employee, ?string $password): void
    {
        if (! $employee->email) {
            return;
        }

        $user = $employee->user ?: User::where('email', $employee->email)->first();

        $attributes = [
            'company_id' => $employee->company_id,
            'name' => $employee->name,
            'email' => $employee->email,
            'role' => 'employee',
            'employee_id' => $employee->id,
            'is_active' => $employee->status === 'active',
        ];

        if ($password) {
            $attributes['password'] = Hash::make($password);
        }

        if ($user) {
            $user->update($attributes);
        } else {
            $attributes['password'] = Hash::make($password ?: str()->random(12));
            $user = User::create($attributes);
        }

        if ($employee->user_id !== $user->id) {
            $employee->update(['user_id' => $user->id]);
        }
    }
}

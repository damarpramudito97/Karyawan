<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LocationResource\Pages;
use App\Models\Location;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class LocationResource extends Resource
{
    protected static ?string $model = Location::class;

    protected static ?string $navigationIcon = 'heroicon-o-map-pin';

    protected static ?string $navigationGroup = 'Pengaturan Presensi';

    protected static ?string $navigationLabel = 'Lokasi / Cabang';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')
                ->label('Nama Lokasi')
                ->placeholder('Contoh: Kantor Pusat, Cabang Yogyakarta')
                ->required()
                ->maxLength(255)
                ->columnSpanFull(),

            Forms\Components\Textarea::make('address')
                ->label('Alamat')
                ->columnSpanFull(),

            Forms\Components\TextInput::make('latitude')
                ->label('Latitude')
                ->numeric()
                ->required()
                ->step(0.0000001)
                ->helperText('Salin koordinat dari Google Maps (klik kanan pada titik lokasi).'),

            Forms\Components\TextInput::make('longitude')
                ->label('Longitude')
                ->numeric()
                ->required()
                ->step(0.0000001),

            Forms\Components\TextInput::make('radius_meters')
                ->label('Radius Geofence (meter)')
                ->numeric()
                ->required()
                ->default(100)
                ->minValue(10)
                ->suffix('meter')
                ->helperText('Karyawan hanya dapat check-in/out jika berada dalam radius ini dari titik koordinat.'),

            Forms\Components\Toggle::make('is_active')
                ->label('Aktif')
                ->default(true),

            Forms\Components\Placeholder::make('map_preview')
                ->label('Pratinjau Peta')
                ->content(fn ($get) => view('filament.components.location-map', [
                    'lat' => $get('latitude') ?: -7.797068,
                    'lng' => $get('longitude') ?: 110.370529,
                    'radius' => $get('radius_meters') ?: 100,
                ]))
                ->columnSpanFull(),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Nama Lokasi')->searchable(),
                Tables\Columns\TextColumn::make('address')->label('Alamat')->limit(40),
                Tables\Columns\TextColumn::make('latitude')->label('Latitude'),
                Tables\Columns\TextColumn::make('longitude')->label('Longitude'),
                Tables\Columns\TextColumn::make('radius_meters')
                    ->label('Radius')
                    ->suffix(' m'),
                Tables\Columns\IconColumn::make('is_active')
                    ->label('Aktif')
                    ->boolean(),
                Tables\Columns\TextColumn::make('employees_count')
                    ->label('Karyawan')
                    ->counts('employees'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLocations::route('/'),
            'create' => Pages\CreateLocation::route('/create'),
            'edit' => Pages\EditLocation::route('/{record}/edit'),
        ];
    }
}

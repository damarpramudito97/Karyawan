<?php

use App\Http\Controllers\Api\Admin\LeaveApprovalController;
use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\LeaveRequestController;
use App\Http\Controllers\Api\ScheduleController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes - Karyawana
|--------------------------------------------------------------------------
|
| Semua route di bawah ini otomatis ter-filter per company (multi-tenant)
| melalui trait BelongsToCompany pada model, berdasarkan company_id user
| yang login (kecuali super_admin).
|
*/

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/logout', [AuthController::class, 'logout']);

    // ===== Mobile: presensi =====
    Route::get('/attendance/today', [AttendanceController::class, 'today']);
    Route::get('/attendance/history', [AttendanceController::class, 'history']);
    Route::post('/attendance/check-in', [AttendanceController::class, 'checkIn']);
    Route::post('/attendance/check-out', [AttendanceController::class, 'checkOut']);

    // ===== Mobile: jadwal kerja =====
    Route::get('/schedule/today', [ScheduleController::class, 'today']);
    Route::get('/schedule/week', [ScheduleController::class, 'week']);

    // ===== Mobile: pengajuan cuti/izin/sakit/lembur/wfh/wfa =====
    Route::get('/leave-requests', [LeaveRequestController::class, 'index']);
    Route::post('/leave-requests', [LeaveRequestController::class, 'store']);
    Route::get('/leave-requests/{leaveRequest}', [LeaveRequestController::class, 'show']);
    Route::post('/leave-requests/{leaveRequest}/cancel', [LeaveRequestController::class, 'cancel']);

    // ===== Admin/HR: approval pengajuan =====
    Route::middleware('role:admin,super_admin')->prefix('admin')->group(function () {
        Route::get('/leave-requests', [LeaveApprovalController::class, 'index']);
        Route::post('/leave-requests/{leaveRequest}/approve', [LeaveApprovalController::class, 'approve']);
        Route::post('/leave-requests/{leaveRequest}/reject', [LeaveApprovalController::class, 'reject']);
    });
});

<?php

use App\Http\Controllers\Billing\BillingController;
use Illuminate\Support\Facades\Route;

// Webhook Midtrans - tanpa auth/CSRF, harus bisa diakses publik dari server Midtrans
Route::post('/webhooks/midtrans', [BillingController::class, 'webhook'])
    ->withoutMiddleware(['web'])
    ->name('webhooks.midtrans');

// Checkout - dipanggil dari Filament Page Billing (perlu login)
Route::middleware(['web', 'auth'])->group(function () {
    Route::post('/billing/checkout/{plan}', [BillingController::class, 'checkout'])->name('billing.checkout');
});

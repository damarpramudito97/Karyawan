<?php

use App\Console\Commands\CheckExpiredSubscriptions;
use Illuminate\Support\Facades\Schedule;

// Jalankan setiap hari jam 01:00 untuk menandai trial/subscription yang expired
Schedule::command(CheckExpiredSubscriptions::class)->dailyAt('01:00');

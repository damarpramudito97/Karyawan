<?php

use App\Http\Controllers\Report\AttendanceReportController;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])->prefix('reports')->name('reports.')->group(function () {
    Route::get('/attendance/pdf', [AttendanceReportController::class, 'pdf'])->name('attendance.pdf');
    Route::get('/attendance/excel', [AttendanceReportController::class, 'excel'])->name('attendance.excel');
    Route::get('/attendance/csv', [AttendanceReportController::class, 'csv'])->name('attendance.csv');
});

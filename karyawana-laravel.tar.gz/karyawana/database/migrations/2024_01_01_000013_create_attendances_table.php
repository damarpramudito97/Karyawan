<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->foreignId('work_schedule_id')->nullable()->constrained('work_schedules')->nullOnDelete();
            $table->foreignId('shift_id')->nullable()->constrained('shifts')->nullOnDelete();
            $table->foreignId('location_id')->nullable()->constrained('locations')->nullOnDelete();

            $table->date('date');

            // Check-in
            $table->timestamp('check_in_at')->nullable();
            $table->decimal('check_in_lat', 10, 7)->nullable();
            $table->decimal('check_in_lng', 10, 7)->nullable();
            $table->decimal('check_in_accuracy', 8, 2)->nullable(); // akurasi GPS dalam meter
            $table->string('check_in_address')->nullable();
            $table->string('check_in_photo')->nullable(); // path selfie
            $table->boolean('check_in_is_mock_location')->default(false);
            $table->decimal('check_in_distance_meters', 10, 2)->nullable(); // jarak ke titik lokasi
            $table->boolean('check_in_within_radius')->default(true);

            // Check-out
            $table->timestamp('check_out_at')->nullable();
            $table->decimal('check_out_lat', 10, 7)->nullable();
            $table->decimal('check_out_lng', 10, 7)->nullable();
            $table->decimal('check_out_accuracy', 8, 2)->nullable();
            $table->string('check_out_address')->nullable();
            $table->string('check_out_photo')->nullable();
            $table->boolean('check_out_is_mock_location')->default(false);
            $table->decimal('check_out_distance_meters', 10, 2)->nullable();
            $table->boolean('check_out_within_radius')->default(true);

            // Perhitungan otomatis
            $table->unsignedInteger('late_minutes')->default(0);
            $table->unsignedInteger('early_leave_minutes')->default(0);
            $table->unsignedInteger('overtime_minutes')->default(0);

            $table->enum('status', [
                'present', 'late', 'absent', 'leave', 'sick', 'permission',
                'wfh', 'wfa', 'day_off',
            ])->default('present');

            $table->text('notes')->nullable();
            $table->timestamps();

            $table->unique(['employee_id', 'date']); // satu record presensi per hari
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendances');
    }
};

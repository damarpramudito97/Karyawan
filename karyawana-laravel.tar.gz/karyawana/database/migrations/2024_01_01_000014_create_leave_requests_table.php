<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('leave_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();

            $table->enum('type', ['cuti', 'izin', 'sakit', 'lembur', 'wfh', 'wfa']);

            $table->date('start_date');
            $table->date('end_date');

            // khusus lembur: jam mulai & selesai pada start_date
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();

            $table->text('reason');
            $table->string('attachment')->nullable(); // surat dokter, dsb

            $table->enum('status', ['pending', 'approved', 'rejected', 'cancelled'])->default('pending');
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->text('approval_notes')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('leave_requests');
    }
};

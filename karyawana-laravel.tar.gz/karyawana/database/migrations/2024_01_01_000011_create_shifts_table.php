<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('shifts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();
            $table->string('name'); // contoh: Shift Pagi, Shift Malam
            $table->time('start_time');
            $table->time('end_time');
            $table->boolean('is_overnight')->default(false); // shift melewati tengah malam

            // toleransi dalam menit
            $table->unsignedInteger('late_tolerance_minutes')->default(0);
            $table->unsignedInteger('early_leave_tolerance_minutes')->default(0);

            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('shifts');
    }
};

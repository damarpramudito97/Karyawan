<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('work_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained('companies')->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->foreignId('shift_id')->nullable()->constrained('shifts')->nullOnDelete();
            $table->foreignId('location_id')->nullable()->constrained('locations')->nullOnDelete();

            $table->date('date');
            $table->boolean('is_day_off')->default(false); // hari libur untuk karyawan ini

            $table->timestamps();

            $table->unique(['employee_id', 'date']); // satu jadwal per karyawan per tanggal
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('work_schedules');
    }
};

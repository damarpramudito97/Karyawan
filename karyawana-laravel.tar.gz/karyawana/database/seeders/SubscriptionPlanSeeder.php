<?php

namespace Database\Seeders;

use App\Models\SubscriptionPlan;
use Illuminate\Database\Seeder;

class SubscriptionPlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            [
                'name' => 'Basic',
                'slug' => 'basic',
                'description' => 'Cocok untuk perusahaan kecil',
                'price' => 99000,
                'billing_cycle' => 'monthly',
                'max_employees' => 25,
                'max_locations' => 1,
                'features' => ['attendance_gps', 'selfie', 'leave_request', 'pdf_report'],
            ],
            [
                'name' => 'Pro',
                'slug' => 'pro',
                'description' => 'Untuk perusahaan menengah dengan banyak cabang',
                'price' => 299000,
                'billing_cycle' => 'monthly',
                'max_employees' => 100,
                'max_locations' => 5,
                'features' => [
                    'attendance_gps', 'selfie', 'leave_request', 'shift_management',
                    'pdf_report', 'excel_report', 'csv_report', 'push_notification',
                ],
            ],
            [
                'name' => 'Enterprise',
                'slug' => 'enterprise',
                'description' => 'Tanpa batas karyawan & cabang',
                'price' => 799000,
                'billing_cycle' => 'monthly',
                'max_employees' => null,
                'max_locations' => null,
                'features' => [
                    'attendance_gps', 'selfie', 'leave_request', 'shift_management',
                    'pdf_report', 'excel_report', 'csv_report', 'push_notification',
                    'priority_support', 'custom_branding',
                ],
            ],
        ];

        foreach ($plans as $plan) {
            SubscriptionPlan::updateOrCreate(['slug' => $plan['slug']], $plan);
        }
    }
}

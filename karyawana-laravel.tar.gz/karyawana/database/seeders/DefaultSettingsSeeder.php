<?php

namespace Database\Seeders;

use App\Models\Company;
use App\Models\Setting;
use Illuminate\Database\Seeder;

class DefaultSettingsSeeder extends Seeder
{
    /**
     * Default setting yang dibuat untuk setiap company baru.
     * Bisa dipanggil saat onboarding tenant (mis. di event Company "created").
     */
    public static function seedForCompany(int $companyId): void
    {
        $defaults = [
            'require_selfie' => '1',                 // wajib selfie saat presensi
            'reject_mock_location' => '1',           // tolak presensi jika fake GPS terdeteksi
            'reject_outside_radius' => '1',          // tolak presensi jika di luar radius
            'max_gps_accuracy_meters' => '50',        // akurasi GPS maksimum yang diterima
        ];

        foreach ($defaults as $key => $value) {
            Setting::setValue($companyId, $key, $value);
        }
    }

    public function run(): void
    {
        Company::all()->each(function (Company $company) {
            self::seedForCompany($company->id);
        });
    }
}

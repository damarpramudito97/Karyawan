class ShiftInfo {
  final int id;
  final String name;
  final String startTime;
  final String endTime;

  ShiftInfo({required this.id, required this.name, required this.startTime, required this.endTime});

  factory ShiftInfo.fromJson(Map<String, dynamic> json) {
    return ShiftInfo(
      id: json['id'],
      name: json['name'],
      startTime: json['start_time'],
      endTime: json['end_time'],
    );
  }
}

class LocationInfo {
  final int id;
  final String name;
  final double? latitude;
  final double? longitude;
  final int? radiusMeters;

  LocationInfo({
    required this.id,
    required this.name,
    this.latitude,
    this.longitude,
    this.radiusMeters,
  });

  factory LocationInfo.fromJson(Map<String, dynamic> json) {
    return LocationInfo(
      id: json['id'],
      name: json['name'],
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      radiusMeters: json['radius_meters'],
    );
  }
}

class CheckEvent {
  final DateTime time;
  final String? photoUrl;
  final double latitude;
  final double longitude;
  final double accuracy;
  final double? distanceMeters;
  final bool withinRadius;
  final bool isMockLocation;

  CheckEvent({
    required this.time,
    this.photoUrl,
    required this.latitude,
    required this.longitude,
    required this.accuracy,
    this.distanceMeters,
    required this.withinRadius,
    required this.isMockLocation,
  });

  factory CheckEvent.fromJson(Map<String, dynamic> json) {
    return CheckEvent(
      time: DateTime.parse(json['time']),
      photoUrl: json['photo_url'],
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      accuracy: (json['accuracy'] as num).toDouble(),
      distanceMeters: (json['distance_meters'] as num?)?.toDouble(),
      withinRadius: json['within_radius'] ?? true,
      isMockLocation: json['is_mock_location'] ?? false,
    );
  }
}

class Attendance {
  final int id;
  final DateTime date;
  final String status;
  final ShiftInfo? shift;
  final LocationInfo? location;
  final CheckEvent? checkIn;
  final CheckEvent? checkOut;
  final int lateMinutes;
  final int earlyLeaveMinutes;
  final int overtimeMinutes;
  final String? notes;

  Attendance({
    required this.id,
    required this.date,
    required this.status,
    this.shift,
    this.location,
    this.checkIn,
    this.checkOut,
    required this.lateMinutes,
    required this.earlyLeaveMinutes,
    required this.overtimeMinutes,
    this.notes,
  });

  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      id: json['id'],
      date: DateTime.parse(json['date']),
      status: json['status'],
      shift: json['shift'] != null ? ShiftInfo.fromJson(json['shift']) : null,
      location: json['location'] != null ? LocationInfo.fromJson(json['location']) : null,
      checkIn: json['check_in'] != null ? CheckEvent.fromJson(json['check_in']) : null,
      checkOut: json['check_out'] != null ? CheckEvent.fromJson(json['check_out']) : null,
      lateMinutes: json['late_minutes'] ?? 0,
      earlyLeaveMinutes: json['early_leave_minutes'] ?? 0,
      overtimeMinutes: json['overtime_minutes'] ?? 0,
      notes: json['notes'],
    );
  }
}

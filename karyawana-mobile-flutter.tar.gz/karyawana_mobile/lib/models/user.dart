class CompanyInfo {
  final int id;
  final String name;
  final String subscriptionStatus;

  CompanyInfo({required this.id, required this.name, required this.subscriptionStatus});

  factory CompanyInfo.fromJson(Map<String, dynamic> json) {
    return CompanyInfo(
      id: json['id'],
      name: json['name'],
      subscriptionStatus: json['subscription_status'] ?? 'trial',
    );
  }
}

class EmployeeInfo {
  final int id;
  final String? employeeCode;
  final String name;
  final String? position;
  final String? photoUrl;

  EmployeeInfo({
    required this.id,
    this.employeeCode,
    required this.name,
    this.position,
    this.photoUrl,
  });

  factory EmployeeInfo.fromJson(Map<String, dynamic> json) {
    return EmployeeInfo(
      id: json['id'],
      employeeCode: json['employee_code'],
      name: json['name'],
      position: json['position'],
      photoUrl: json['photo_url'],
    );
  }
}

class AppUser {
  final int id;
  final String name;
  final String email;
  final String role; // super_admin | admin | employee
  final CompanyInfo? company;
  final EmployeeInfo? employee;

  AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.company,
    this.employee,
  });

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      role: json['role'],
      company: json['company'] != null ? CompanyInfo.fromJson(json['company']) : null,
      employee: json['employee'] != null ? EmployeeInfo.fromJson(json['employee']) : null,
    );
  }
}

# Karyawana Mobile (Flutter)

> **Status: dalam pengembangan.** Ini adalah Fase 6 dari project Karyawana —
> baru berisi setup awal (dependencies & model data). Layar (login, check-in,
> jadwal, pengajuan) akan ditambahkan secara bertahap.

## Yang sudah ada

- `pubspec.yaml` — daftar dependency: geolocator (GPS + deteksi mock location),
  camera (selfie), dio (HTTP client), provider (state management), firebase
  messaging (push notification), flutter_map (peta geofence), dll.
- `lib/models/user.dart` — model `AppUser`, `CompanyInfo`, `EmployeeInfo`
  (cocok dengan response `POST /api/login` pada backend Laravel).
- `lib/models/attendance.dart` — model `Attendance`, `CheckEvent`, `ShiftInfo`,
  `LocationInfo` (cocok dengan response `AttendanceResource` pada backend).

## Yang akan ditambahkan

- `lib/services/api_service.dart` — wrapper Dio untuk konsumsi REST API
- `lib/services/location_service.dart` — geofence + deteksi mock location
- `lib/screens/auth/login_screen.dart`
- `lib/screens/home/home_screen.dart`
- `lib/screens/attendance/check_in_screen.dart` (kamera + GPS, sesuai mockup)
- `lib/screens/schedule/schedule_screen.dart`
- `lib/screens/leave_request/*` — form pengajuan cuti/izin/sakit/lembur/wfh/wfa
- Integrasi Firebase Cloud Messaging untuk notifikasi

## Setup (setelah lengkap)

```bash
flutter pub get
flutter run
```

Pastikan backend Laravel (lihat repo `karyawana`) sudah berjalan dan endpoint
API dapat diakses dari emulator/device (gunakan IP lokal, bukan `localhost`,
jika testing di device fisik).
